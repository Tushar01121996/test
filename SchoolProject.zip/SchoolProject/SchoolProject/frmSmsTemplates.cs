﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmSmsTemplates : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmSmsTemplates()
        {
            InitializeComponent();
        }
       
        public void clearcontrols()
        {
            lblId.Text = "";
            txtdetails.Text = "";
            txtsms.Text = "";
        }
        public void Bindgrid()
        {
            sql = "select Id, SMS_TEMPLATES from Sms_Templates";
            dt = dh.DataTable(sql);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].Width = 220;
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                //lblId.Text = getMaxId();
                string sql = "select * from Sms_Templates where Id='" + lblId.Text + "'";
                dt = dh.DataTable(sql);

                if (dt.Rows.Count > 0)
                {
                    sql = "update Sms_Templates set SMS_TEMPLATES ='" + txtsms.Text + "', SMS_DETAILS='" + txtdetails.Text + "' where Id='" + lblId.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Update !!");
                }
                else
                {

                    sql = "insert into Sms_Templates (SMS_TEMPLATES,SMS_DETAILS)values('" + txtsms.Text + "','" + txtdetails.Text + "')";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Saved !!");
                }
                txtsms.Enabled = false;
                txtdetails.Enabled = false;
                Bindgrid();
                btnAdd.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtsms.Enabled = false;
            txtdetails.Enabled = false;
            clearcontrols();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtdetails.Enabled = true;
            txtsms.Enabled = true;
            clearcontrols();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                //sql = "select * from class_section_manage where sid='" + lblId.Text + "'";
                //dt = dh.DataTable(sql);
                //if (dt.Rows.Count > 0)
                //{
                //    MessageBox.Show("Class cannot delete because it is used in other process !!");
                //    return;
                //}
                //else
                //{
                //    sql = "delete from class_section_manage where sid='" + lblId.Text + "'";
                //    dh.ExecuteQuery(sql);
                //    MessageBox.Show("Data Delete !!");
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sql = " select * from Sms_Templates  where SMS_TEMPLATES like '%" + txtsearch.Text + "%'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
                dataGridView1.Columns[0].Width = 50;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                sql = "select * from Sms_Templates where Id='" + id.ToString() + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    lblId.Text = id;
                    string sms = dt.Rows[0]["SMS_TEMPLATES"].ToString();
                    string details = dt.Rows[0]["SMS_DETAILS"].ToString();
                    txtsms.Text = sms;
                    txtdetails.Text = details;
                    //.Text = dt.Rows[0]["sname"].ToString();
                    //lblId.Text = sid;
                }
                txtdetails.Enabled = true;
                txtsms.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void frmclasssectionManage_Load(object sender, EventArgs e)
        {
            lblId.Text = "";
          
            Bindgrid();
            txtdetails.Enabled = false;
            txtsms.Enabled = false;
        }
    }
}
