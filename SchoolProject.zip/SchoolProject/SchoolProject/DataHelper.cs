﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Security.Cryptography;
using System.IO;

namespace SchoolProject
{
    class DataHelper
    {
        //Self Connection
        //public static string servername = "DESKTOP-A7RURIK\\SQLEXPRESS";
        //public static string database = "Gst_Courier";
        //public static string userid = string.Empty;
        //public static string pwd = string.Empty;

        //Client Connection
        public static string servername = "DESKTOP-KT486NF\\SQLEXPRESS";
        public static string database = "Gst_Courier";
        public static string userid = string.Empty;
        public static string pwd = string.Empty;

        //SqlConnection con = new SqlConnection("server=" + servername + ";database=" + database + ";tr+usted_connection=true");
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["SchoolProject"].ToString());

        SqlDataAdapter sda;
        SqlCommand cmd;
        DataTable dt;
        public static string FinYear = "2019-2020";
        public static string UserId;
        public string ComputerName()
        {
            string computername = System.Net.Dns.GetHostName();
            return computername;
        }
        public DataTable getSchoolDetails()
        {
            string sql = string.Empty;
            DataTable dt = new DataTable();
            sql = "select * from SchoolSettings";
            dt = DataTable(sql);
            return dt;
        }

        public DataTable DataTable(string query)
        {
            sda = new SqlDataAdapter(query, con);
            dt = new DataTable();
            sda.Fill(dt);
            return dt;
        }
        public void ExecuteQuery(string query)
        {
            con.Open();
            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public string GetMonthName(int i)
        {
            string Months = string.Empty;
            if (i == 1)
                Months = "APR";
            if (i == 2)
                Months = "MAY";
            if (i == 3)
                Months = "JUN";
            if (i == 4)
                Months = "JUL";
            if (i == 5)
                Months = "AUG";
            if (i == 6)
                Months = "SEP";
            if (i == 7)
                Months = "OCT";
            if (i == 8)
                Months = "NOV";
            if (i == 9)
                Months = "DEC";
            if (i == 10)
                Months = "JAN";
            if (i == 11)
                Months = "FEB";
            if (i == 12)
                Months = "MAR";
            return Months;

        }
        public string SendSMS(string mobile, string message)
        {
            try
            {
                WebClient client = new WebClient();
                //string to, message;
                //to = txtmobile.Text;
                //message = richTextBox1.Text;
                // string baseURL = "https://platform.clickatell.com/messages/http/send?apiKey=3_MOnX9bQuqMZDRf4V2DbA==&to=" + to + "&content=" + message + "";
                //string baseURL = "http://api.clickatell.com/http/sendmsg?user=zisan94268&password=OYeNLVUHTNIHbD&api_id=3528011&to='" + to + "'&text='" + message + "'";
                string baseURL = "https://platform.clickatell.com/messages/http/send?apiKey=3_MOnX9bQuqMZDRf4V2DbA==&to=" + mobile + "&content=" + message + "";
                client.OpenRead(baseURL);
                return "true";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        public void CreateBackup()
        {
            string sql = "BACKUP DATABASE SchoolProject TO DISK = 'E:\\SchoolBackup\\School" + DateTime.Now.ToShortDateString() + ".bak';";
            ExecuteQuery(sql);
        }
        public static string Encrypt(string encryptString)
        {
            string EncryptionKey = "0ram@1234xxxxxxxxxxtttttuuuuuiiiiio";  //we can change the code converstion key as per our requirement    
            byte[] clearBytes = Encoding.Unicode.GetBytes(encryptString);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {      
            0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76      
        });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    encryptString = Convert.ToBase64String(ms.ToArray());
                }
            }
            return encryptString;
        }

        public static string Decrypt(string cipherText)
        {
            string EncryptionKey = "0ram@1234xxxxxxxxxxtttttuuuuuiiiiio";  //we can change the code converstion key as per our requirement, but the decryption key should be same as encryption key    
            cipherText = cipherText.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {      
            0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76      
        });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
    }
}
