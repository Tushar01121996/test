﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmSetctionMaster : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmSetctionMaster()
        {
            InitializeComponent();
        }
        public void clearcontrols()
        {
            txtsection.Text = "";
            lblId.Text = "";
        }
        public string getMaxId()
        {
            sql = "select isnull(max(isnull(Convert(int,substring(sid,3,6)),0)),0) + 1 from section_mas";
            dt = dh.DataTable(sql);
            string sid = dt.Rows[0][0].ToString();
            return sid;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtsection.Enabled = true;
            clearcontrols();
            txtsection.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtsection.Enabled = false;
            clearcontrols();
        }
        public void Bindgrid()
        {
            sql = "select sid,sname from section_mas";
            dt = dh.DataTable(sql);
            dataGridView1.DataSource = dt;
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                //lblId.Text = getMaxId();
                string sql = "select * from section_mas where sid='" + lblId.Text + "'";
                dt = dh.DataTable(sql);

                if (dt.Rows.Count > 0)
                {
                    sql = "update section_mas set sname='" + txtsection.Text + "' where sid='" + lblId.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Update !!");
                }
                else
                {
                    string sid = "SE" + getMaxId();
                    sql = "insert into section_mas (sid,sname)values('" + sid + "','" + txtsection.Text.Trim() + "')";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Saved !!");
                }
                txtsection.Enabled = false;
                Bindgrid();
                btnAdd.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                sql = "select * from class_section_manage where sid='" + lblId.Text + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Class cannot delete because it is used in other process !!");
                    return;
                }
                else
                {
                    sql = "delete from section_mas where sid='" + lblId.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Delete !!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sql = "select sid,sname from section_mas where sname like '%" + txtsearch.Text + "%'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string sid = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                sql = "select * from section_mas where sid='" + sid.ToString() + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    txtsection.Text = dt.Rows[0]["sname"].ToString();
                    lblId.Text = sid;
                }
                txtsection.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtsection_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                //btnsave.Focus();
            }
        }

        private void frmSetctionMaster_Load(object sender, EventArgs e)
        {
            txtsection.Enabled = false;
            btnAdd.Focus();
            Bindgrid();
        }
    }
}
