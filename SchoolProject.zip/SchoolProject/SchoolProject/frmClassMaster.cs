﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmClassMaster : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmClassMaster()
        {
            InitializeComponent();
        }
        public void clearcontrols()
        {
            txtclass.Text = "";
            lblId.Text = "";
        }
        public string getMaxId()
        {
            sql = "select isnull(max(isnull(Convert(int,substring(cid,3,6)),0)),0) + 1 from class_mas";
            dt = dh.DataTable(sql);
            string cid = dt.Rows[0][0].ToString();
            return cid;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            txtclass.Enabled = true;
            clearcontrols();
            txtclass.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtclass.Enabled = false;
            clearcontrols();
        }
        public void Bindgrid()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            dataGridView1.DataSource = dt;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                //lblId.Text = getMaxId();
                string sql = "select * from class_mas where cid='" + lblId.Text + "'";
                dt = dh.DataTable(sql);

                if (dt.Rows.Count > 0)
                {
                    sql = "update class_mas set cname='" + txtclass.Text + "' where cid='" + lblId.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Update !!");
                }
                else
                {
                    string cid = "CL" + getMaxId();
                    sql = "insert into class_mas (cid,cname)values('" + cid + "','" + txtclass.Text.Trim() + "')";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Saved !!");
                }
                txtclass.Enabled = false;
                Bindgrid();
                btnAdd.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                sql = "select * from class_section_manage where cid='" + lblId.Text + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Class cannot delete because it is used in other process !!");
                    return;
                }
                else
                {
                    sql = "delete from class_mas where cid='" + lblId.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Delete !!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void frmClassMaster_Load(object sender, EventArgs e)
        {
            txtclass.Enabled = false;
            btnAdd.Focus();
            Bindgrid();
            
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string cid = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                sql = "select * from class_mas where cid='" + cid.ToString() + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    txtclass.Text = dt.Rows[0]["cname"].ToString();
                    lblId.Text = cid;
                }
                txtclass.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sql = "select cid,cname from class_mas where cname like '%" + txtsearch.Text + "%'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtclass_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtclass_Enter(object sender, EventArgs e)
        {
            //btnsave.Focus();
        }

        private void txtclass_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                btnsave.Focus();
            }
        }

        private void btnAdd_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                txtclass.Focus();
            }
        }
    }
}
