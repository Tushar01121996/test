﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmclasssectionManage : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmclasssectionManage()
        {
            InitializeComponent();
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            cmbclass.DataSource = dt;
            cmbclass.DisplayMember = "cname";
            cmbclass.ValueMember = "cid";
        }
        public void BindSection()
        {
            sql = "select sid,sname from section_mas";
            dt = dh.DataTable(sql);
            cmbsection.DataSource = dt;
            cmbsection.DisplayMember = "sname";
            cmbsection.ValueMember = "sid";
        }
        public void clearcontrols()
        {
            lblId.Text = "";
            if (cmbclass.SelectedIndex > 0)
            {
                cmbclass.SelectedIndex = 0;
            }
            if (cmbsection.SelectedIndex > 0)
            {
                cmbsection.SelectedIndex = 0;
            }
        }
        public void Bindgrid()
        {
            sql = "select cs.Id, c.cname,s.sname from class_section_manage cs inner join class_mas c on c.cid=cs.cid inner join section_mas s on s.sid=cs.sid";
            dt = dh.DataTable(sql);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Width = 50;
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                //lblId.Text = getMaxId();
                string sql = "select * from class_section_manage where Id='" + lblId.Text + "'";
                dt = dh.DataTable(sql);

                if (dt.Rows.Count > 0)
                {
                    sql = "update class_section_manage set cid ='" + cmbclass.SelectedValue + "', sid='" + cmbsection.SelectedValue + "' where Id='" + lblId.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Update !!");
                }
                else
                {

                    sql = "insert into class_section_manage (cid,sid)values('" + cmbclass.SelectedValue + "','" + cmbsection.SelectedValue + "')";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Saved !!");
                }
                cmbsection.Enabled = false;
                cmbclass.Enabled = false;
                Bindgrid();
                btnAdd.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            cmbsection.Enabled = false;
            cmbclass.Enabled = false;
            clearcontrols();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            cmbsection.Enabled = true;
            cmbclass.Enabled = true;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                //sql = "select * from class_section_manage where sid='" + lblId.Text + "'";
                //dt = dh.DataTable(sql);
                //if (dt.Rows.Count > 0)
                //{
                //    MessageBox.Show("Class cannot delete because it is used in other process !!");
                //    return;
                //}
                //else
                //{
                //    sql = "delete from class_section_manage where sid='" + lblId.Text + "'";
                //    dh.ExecuteQuery(sql);
                //    MessageBox.Show("Data Delete !!");
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sql = "select cs.Id, c.cname,s.sname from class_section_manage cs inner join class_mas c on c.cid=cs.cid inner join section_mas s on s.sid=cs.sid where c.cname like '%" + txtsearch.Text + "%'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
                dataGridView1.Columns[0].Width = 50;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                sql = "select * from class_section_manage where Id='" + id.ToString() + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    lblId.Text = id;
                    string cid = dt.Rows[0]["cid"].ToString();
                    string sid = dt.Rows[0]["sid"].ToString();
                    cmbclass.SelectedValue = cid;
                    cmbsection.SelectedValue = sid;
                    //.Text = dt.Rows[0]["sname"].ToString();
                    //lblId.Text = sid;
                }
                cmbsection.Enabled = true;
                cmbclass.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void frmclasssectionManage_Load(object sender, EventArgs e)
        {
            lblId.Text = "";
            BindClass();
            BindSection();
            Bindgrid();
            cmbclass.Enabled = false;
            cmbsection.Enabled = false;
        }
    }
}
