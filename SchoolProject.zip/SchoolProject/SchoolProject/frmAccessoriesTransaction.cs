﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmAccessoriesTransaction : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        int sum_of_price = 0;
        bool chk = false;
        public frmAccessoriesTransaction()
        {
            InitializeComponent();
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);
            cmbclass.DataSource = dt;

            cmbclass.DisplayMember = "cname";
            cmbclass.ValueMember = "cid";
        }
        public void BindKitName()
        {
            sql = "select distinct KitName from AccessoriesMaster";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "--Kit Name--";
            dt.Rows.InsertAt(row, 0);
            cmbKitName.DataSource = dt;

            cmbKitName.DisplayMember = "KitName";
            cmbKitName.ValueMember = "KitName";
        }
        public void BindSection()
        {
            cmbsection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbclass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbsection.DataSource = dt;

            cmbsection.DisplayMember = "sname";
            cmbsection.ValueMember = "sid";
        }
        public void BindStudents()
        {
            cmbstudent.DataSource = null;

            sql = "select StuId,Name from Admission where IsActive ='1' and Class='" + cmbclass.SelectedValue + "' and Section ='" + cmbsection.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Student--";
            dt.Rows.InsertAt(row, 0);
            cmbstudent.DataSource = dt;

            cmbstudent.DisplayMember = "Name";
            cmbstudent.ValueMember = "StuId";
        }
        public void getStudentData()
        {
            if (cmbstudent.SelectedIndex > 0)
            {
                sql = "select * from Admission where StuId ='" + cmbstudent.SelectedValue + "'";
                dt = dh.DataTable(sql);
                lblfathername.Text = dt.Rows[0]["Fname"].ToString();

                sql = "select Top 1 * from Fee_RecMain where Class='" + cmbclass.SelectedValue + "' and Section='" + cmbsection.SelectedValue + "' and StuId='" + cmbstudent.SelectedValue + "'";
                sql += " order by Convert(int,substring(RecNo,5,10)) desc";
                dt = dh.DataTable(sql);
            }
        }
        private void frmAccessoriesTransaction_Load(object sender, EventArgs e)
        {
            BindClass();
            BindKitName();
        }

        private void cmbclass_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindSection();
        }

        private void cmbsection_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindStudents();
        }

        private void cmbstudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            getStudentData();
        }

        private void cmbKitName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                sql = "select *  from AccessoriesMaster where KitName='" + cmbKitName.SelectedValue + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    int sum = 0;
                    dataGridView1.Rows.Clear();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dataGridView1.Rows.Add(dt.Rows[i]["AccName"].ToString(), dt.Rows[i]["Price"].ToString());
                        sum = sum + Convert.ToInt32(dt.Rows[i]["Price"].ToString());
                    }
                    txttotal.Text = sum.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (cmbKitName.SelectedIndex > 0)
            {
                // int price = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString());

                
                //for (int i = 0; i < dataGridView1.Rows.Count; i++)
                //{
                //    chk = Convert.ToBoolean(dataGridView1.Rows[i].Cells[2].Value);
                //    if (chk == true)
                //    {
                //        int price = Convert.ToInt32(dataGridView1.Rows[i].Cells[1].Value.ToString());
                //        sum_of_price = sum_of_price + Convert.ToInt32(price);
                //    }
                //}
                //txttotal.Text = sum_of_price.ToString();
                //calc();
            }
        }
        public void calc()
        {
            int dis = txtdiscount.Text == string.Empty ? 0 : Convert.ToInt32(txtdiscount.Text);
            int total = txttotal.Text == string.Empty ? 0 : Convert.ToInt32(txttotal.Text);
            int netAmt = total - dis;
            textBox1.Text = netAmt.ToString();
        }

        private void txtdiscount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbKitName.SelectedIndex > 0)
                {
                    calc();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_CellStateChanged(object sender, DataGridViewCellStateChangedEventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 2)
                {
                    chk = Convert.ToBoolean(dataGridView1.CurrentRow.Cells[2].Value);
                    if (chk == true)
                    {
                        int price = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                        sum_of_price = sum_of_price + Convert.ToInt32(price);
                    }
                    if (chk == false)
                    {
                        int price = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                        sum_of_price = sum_of_price - Convert.ToInt32(price);
                    }
                }
                txttotal.Text = sum_of_price.ToString();
                calc();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
