﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;

namespace SchoolProject
{
    public partial class frmSendSMS : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmSendSMS()
        {
            InitializeComponent();
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);
            cmbClass.DataSource = dt;

            cmbClass.DisplayMember = "cname";
            cmbClass.ValueMember = "cid";
        }
        public void BindSMSTemplates()
        {
            sql = "select SMS_TEMPLATES,SMS_TEMPLATES from Sms_Templates";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            //row[0] = "0";
            row[0] = "--SMS TEMPLATES--";
            dt.Rows.InsertAt(row, 0);
            cmbsmstemplates.DataSource = dt;

            cmbsmstemplates.DisplayMember = "SMS_TEMPLATES";
            cmbsmstemplates.ValueMember = "SMS_TEMPLATES";
        }
        public void BindSMSdetails()
        {
            cmbSection.DataSource = null;

            sql = "select SMS_DETAILS from Sms_Templates  where SMS_TEMPLATES='" + cmbsmstemplates.SelectedValue + "'";
            dt = dh.DataTable(sql);
            richTextBox1.Text = dt.Rows[0][0].ToString();
        }
        public void BindSection()
        {
            cmbSection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbClass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbSection.DataSource = dt;

            cmbSection.DisplayMember = "sname";
            cmbSection.ValueMember = "sid";
        }
        public void BindStudents()
        {
            cmbStudents.DataSource = null;

            sql = "select StuId,Name from Admission where IsActive ='1' and Class='" + cmbClass.SelectedValue + "' and Section ='" + cmbSection.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Student--";
            dt.Rows.InsertAt(row, 0);
            cmbStudents.DataSource = dt;

            cmbStudents.DisplayMember = "Name";
            cmbStudents.ValueMember = "StuId";
        }
        public void getStudentData()
        {
            if (cmbStudents.SelectedIndex > 0)
            {
                sql = "select * from Admission where StuId ='" + cmbStudents.SelectedValue + "'";
                dt = dh.DataTable(sql);

            }
        }
        private void frmSendSMS_Load(object sender, EventArgs e)
        {
            try
            {
                BindClass();
                BindSMSTemplates();
            }
            catch (Exception ex)
            {

            }
            //"https://platform.clickatell.com/messages/http/send?apiKey=3_MOnX9bQuqMZDRf4V2DbA==&to=&content="
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(richTextBox1.Text))
                {
                    if (rdbManual.Checked == true)
                    {
                        string mobile = "";
                        if (txtmobile.Text.Length == 10)
                        {
                            mobile = "91" + txtmobile.Text;
                            string message = richTextBox1.Text;
                            string result = dh.SendSMS(mobile, message);
                            if (result == "true")
                            {
                                MessageBox.Show("SMS sent successfully !!");
                            }
                            else
                            {
                                MessageBox.Show("Something went wrong!!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Mobile No. " + txtmobile.Text + "not valid..");
                            return;
                        }
                    }
                    else
                    {
                        for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                        {
                            bool flag = Convert.ToBoolean(dataGridView1.Rows[i].Cells[0].Value);
                            if (flag == true)
                            {
                                if (dataGridView1.Rows[i].Cells[3].Value.ToString().Length == 10)
                                {
                                    string mobile = "";
                                    mobile = "91" + dataGridView1.Rows[i].Cells[3].Value.ToString();
                                    string message = richTextBox1.Text;
                                    string result = dh.SendSMS(mobile, message);
                                    //if (result == "true")
                                    //{
                                    //    MessageBox.Show("SMS sent successfully !!");
                                    //}
                                    //else
                                    //{
                                    //    MessageBox.Show("Something went wrong!!");
                                    //}
                                }
                                else
                                {
                                    MessageBox.Show("Mobile No." + dataGridView1.Rows[i].Cells[3].Value.ToString() + " not valid..");
                                    continue;
                                }
                            }
                           
                        }
                        MessageBox.Show("SMS sent successfully !!"); 
                    }
                }
                else
                {
                    MessageBox.Show("Message cannot empty..");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void cmbClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindSection();
            if (cmbClass.SelectedIndex > 0)
            {
                sql = "select Name,FName,Mobile from Admission where Class='" + cmbClass.SelectedValue + "'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
                //for (int i = 0; i < dt.Rows.Count; i++)
                //{
                //    dataGridView1.Rows.Add(dt.Rows[i]["Name"].ToString(), dt.Rows[i]["Fname"].ToString(), dt.Rows[i]["Mobile"].ToString());
                //}
            }
        }

        private void cmbSection_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindStudents();
            if (cmbClass.SelectedIndex > 0 && cmbSection.SelectedIndex > 0)
            {
                sql = "select Name,FName,Mobile from Admission where Class='" + cmbClass.SelectedValue + "' and Section='" + cmbSection.SelectedValue + "'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
                //for (int i = 0; i < dt.Rows.Count; i++)
                //{
                //    dataGridView1.Rows.Add(dt.Rows[i]["Name"].ToString(), dt.Rows[i]["Fname"].ToString(), dt.Rows[i]["Mobile"].ToString());
                //}
            }
        }

        private void cmbStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            getStudentData();
            if (cmbClass.SelectedIndex > 0 && cmbSection.SelectedIndex > 0 && cmbStudents.SelectedIndex > 0)
            {
                sql = "select Name,FName,Mobile from Admission where Class='" + cmbClass.SelectedValue + "' and Section='" + cmbSection.SelectedValue + "' and StuId='" + cmbStudents.SelectedValue + "'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
                //for (int i = 0; i < dt.Rows.Count; i++)
                //{
                //    dataGridView1.Rows.Add(dt.Rows[i]["Name"].ToString(), dt.Rows[i]["Fname"].ToString(), dt.Rows[i]["Mobile"].ToString());
                //}
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            clearcontrols();
        }
        public void clearcontrols()
        {
            cmbClass.SelectedIndex = 0;
            cmbStudents.SelectedIndex = 0;
            cmbSection.SelectedIndex = 0;
            txtmobile.Text = "";
            richTextBox1.Text = "";
            cmbsmstemplates.SelectedIndex = 0;
        }

        private void cmbsmstemplates_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                BindSMSdetails();
            }
            catch (Exception ex)
            {

            }
        }

        private void rdbselected_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbselected.Checked == true)
            {
                txtmobile.Text = "";
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    dataGridView1.Rows[i].Cells[0].Value = true;
                }
            }
            else
            {
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    dataGridView1.Rows[i].Cells[0].Value = false;
                }
            }
        }
    }
}
