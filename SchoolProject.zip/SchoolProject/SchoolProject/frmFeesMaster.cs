﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmFeesMaster : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmFeesMaster()
        {
            InitializeComponent();
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);
            cmbclass.DataSource = dt;

            cmbclass.DisplayMember = "cname";
            cmbclass.ValueMember = "cid";
        }
        public void BindSection()
        {
            cmbsection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbclass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbsection.DataSource = dt;

            cmbsection.DisplayMember = "sname";
            cmbsection.ValueMember = "sid";
        }
        public void BindFeesHead()
        {

            sql = "select HeadId,HeadName from FeesHead";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Fees Head--";
            dt.Rows.InsertAt(row, 0);
            cmbfeeshead.DataSource = dt;

            cmbfeeshead.DisplayMember = "HeadName";
            cmbfeeshead.ValueMember = "HeadId";
        }
        public void clearcontrols()
        {
            if (cmbfeeshead.SelectedIndex > 0)
                cmbfeeshead.SelectedIndex = 0;
            if (cmbclass.SelectedIndex > 0)
                cmbclass.SelectedIndex = 0;
            if (cmbsection.SelectedIndex > 0)
                cmbsection.SelectedIndex = 0;
            cmbMonth.Text = "";
            txtAmount.Text = "";
            lblId.Text = "";
        }
        public string getMaxId()
        {
            sql = "select isnull(max(isnull(Convert(int,substring(ExpenseId,3,6)),0)),0) + 1 from FeesMaster";
            dt = dh.DataTable(sql);
            string cid = dt.Rows[0][0].ToString();
            return cid;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            panel1.Enabled = true;
            clearcontrols();
            txtAmount.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            panel1.Enabled = true;
            clearcontrols();
        }
        public void Bindgrid()
        {
            sql = "";
            sql += "             select fm.Id, fm.Month,cm.cname as Class , sm.sname as Section, fh.HeadName,fm.Amount from FeesMaster fm";
            sql += " inner join class_mas cm on cm.cid = fm.Class";
            sql += " inner join section_mas sm on sm.sid=fm.Section";
            sql += " inner join FeesHead fh on fh.HeadId=fm.FeesHead order by fm.Id asc";
            dt = dh.DataTable(sql);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Width = 30;
            dataGridView1.Columns[1].Width = 70;
            dataGridView1.Columns[2].Width = 70;
            dataGridView1.Columns[3].Width = 70;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                //lblId.Text = getMaxId();
                

                string sql = "select * from FeesMaster where Id='" + lblId.Text + "'";
                dt = dh.DataTable(sql);

                if (dt.Rows.Count > 0)
                {
                    sql = "update FeesMaster set Amount='" + txtAmount.Text + "' , Month='" + cmbMonth.Text + "' ,Class='" + cmbclass.SelectedValue + "' ,Section='" + cmbsection.SelectedValue + "' ,FeesHead='" + cmbfeeshead.SelectedValue + "' where Id='" + lblId.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Update !!");
                }
                else
                {
                    string query = string.Empty;
                    DataTable dt2 = new DataTable();
                    query = "select * from FeesMaster where Month='" + cmbMonth.Text + "' and Class='" + cmbclass.SelectedValue + "' and Section='" + cmbsection.SelectedValue + "' and FeesHead='" + cmbfeeshead.SelectedValue + "'";
                    dt2 = dh.DataTable(query);
                    if (dt2.Rows.Count > 0)
                    {
                        MessageBox.Show("Duplicate Entry Not Allowed !!");
                        return;
                    }
                    if (string.IsNullOrEmpty(cmbsection.Text) || cmbsection.SelectedIndex == 0)
                    {
                        sql = "select cid,sid from class_section_manage where cid='" + cmbclass.SelectedValue + "'";
                        dt = dh.DataTable(sql);
                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                DataTable dt1 = new DataTable();
                                sql = "select * from FeesMaster where Month='" + cmbMonth.Text + "' and Class='" + cmbclass.SelectedValue + "' and Section='" + dt.Rows[i]["sid"].ToString() + "' and FeesHead='" + cmbfeeshead.SelectedValue + "'";
                                dt1 = dh.DataTable(sql);
                                if (dt1.Rows.Count > 0)
                                {
                                    //continue;
                                }
                                else
                                {
                                    sql = "insert into FeesMaster (Month,Class,Section,FeesHead,Amount)values('" + cmbMonth.Text + "','" + cmbclass.SelectedValue + "','" + dt.Rows[i]["sid"].ToString() + "','" + cmbfeeshead.SelectedValue + "','" + txtAmount.Text.Trim() + "')";
                                    dh.ExecuteQuery(sql);
                                }
                            }
                        }
                    }
                    else
                    {
                        sql = "insert into FeesMaster (Month,Class,Section,FeesHead,Amount)values('" + cmbMonth.Text + "','" + cmbclass.SelectedValue + "','" + cmbsection.SelectedValue + "','" + cmbfeeshead.SelectedValue + "','" + txtAmount.Text.Trim() + "')";
                        dh.ExecuteQuery(sql);
                    }
                    MessageBox.Show("Data Saved !!");
                }
                //txtAmount.Enabled = false;
                panel1.Enabled = false;
                Bindgrid();
                btnAdd.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                //sql = "select * from class_section_manage where cid='" + lblId.Text + "'";
                //dt = dh.DataTable(sql);
                //if (dt.Rows.Count > 0)
                //{
                //    MessageBox.Show("Class cannot delete because it is used in other process !!");
                //    return;
                //}
                //else
                //{
                //    sql = "delete from FeesMaster where cid='" + lblId.Text + "'";
                //    dh.ExecuteQuery(sql);
                //    MessageBox.Show("Data Delete !!");
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void frmClassMaster_Load(object sender, EventArgs e)
        {
            panel1.Enabled = false;
            BindClass();
            //BindSection();
            BindFeesHead();
            btnAdd.Focus();
            Bindgrid();
            lblId.Text = "";
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                sql = "select * from FeesMaster where Id='" + id.ToString() + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    string cid = dt.Rows[0]["Class"].ToString();
                    string sid = dt.Rows[0]["Section"].ToString();
                    string Month = dt.Rows[0]["Month"].ToString();
                    string HeadID = dt.Rows[0]["FeesHead"].ToString();
                    string Amount = dt.Rows[0]["Amount"].ToString();

                    cmbclass.SelectedValue = cid;
                    cmbsection.SelectedValue = sid;
                    cmbMonth.Text = Month;
                    cmbfeeshead.SelectedValue = HeadID;
                    txtAmount.Text = Amount;
                    lblId.Text = id;
                }
                panel1.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sql = "";
                sql += "             select fm.Id, fm.Month,cm.cname as Class , sm.sname as Section, fh.HeadName,fm.Amount from FeesMaster fm";
                sql += " inner join class_mas cm on cm.cid = fm.Class";
                sql += " inner join section_mas sm on sm.sid=fm.Section";
                sql += " inner join FeesHead fh on fh.HeadId=fm.FeesHead where fm.Month like '%" + txtsearch.Text + "%' or cm.cname like '%" + txtsearch.Text + "%' or fh.HeadName like '%" + txtsearch.Text + "%' order by fm.Id asc";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
                dataGridView1.Columns[0].Width = 30;
                dataGridView1.Columns[1].Width = 70;
                dataGridView1.Columns[2].Width = 70;
                dataGridView1.Columns[3].Width = 70;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtfesshead_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtfesshead_Enter(object sender, EventArgs e)
        {
            //btnsave.Focus();
        }

        private void txtfesshead_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                btnsave.Focus();
            }
        }

        private void btnAdd_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                cmbclass.Focus();
            }
        }

        private void cmbclass_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindSection();
        }
    }
}
