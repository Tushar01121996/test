﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmAccessoriesMaster : Form
    {
        DataHelper dh = new DataHelper();
        string sql = string.Empty;
        DataTable dt = new DataTable();
        public frmAccessoriesMaster()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                sql = "select * from AccessoriesMaster";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    sql = "delete from AccessoriesMaster where KitName ='" + txtkitname.Text + "'";
                    dh.ExecuteQuery(sql);
                    for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                    {
                        string AccName = dataGridView1.Rows[i].Cells[0].Value.ToString();
                        string Price = dataGridView1.Rows[i].Cells[1].Value.ToString();
                        sql = "insert into AccessoriesMaster (KitName,AccName,Price)values('" + txtkitname.Text + "','" + AccName + "','" + Price + "')";
                        dh.ExecuteQuery(sql);
                    }
                }
                else
                {
                    for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                    {
                        string AccName = dataGridView1.Rows[i].Cells[0].Value.ToString();
                        string Price = dataGridView1.Rows[i].Cells[1].Value.ToString();
                        sql = "insert into AccessoriesMaster (KitName,AccName,Price)values('" + txtkitname.Text + "','" + AccName + "','" + Price + "')";
                        dh.ExecuteQuery(sql);
                    }
                }
                MessageBox.Show("Kit Created Successfully !!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void clearcontrols()
        {
            txtkitname.Text = "";
            dataGridView1.Rows.Clear();
        }
        public void getdata()
        {
            sql = "select * from AccessoriesMaster";
            dt = dh.DataTable(sql);
            if (dt.Rows.Count > 0)
            {
                txtkitname.Text = dt.Rows[0]["KitName"].ToString();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dataGridView1.Rows.Add(dt.Rows[i]["AccName"].ToString(), dt.Rows[i]["Price"].ToString());
                }
            }
        }

        private void frmAccessoriesMaster_Load(object sender, EventArgs e)
        {
            getdata();
        }
    }
}
