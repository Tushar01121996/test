﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmStudentList : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmStudentList()
        {
            InitializeComponent();
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);
            cmbClass.DataSource = dt;

            cmbClass.DisplayMember = "cname";
            cmbClass.ValueMember = "cid";
        }
        public void BindSection()
        {
            cmbSection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbClass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbSection.DataSource = dt;

            cmbSection.DisplayMember = "sname";
            cmbSection.ValueMember = "sid";
        }
        private void frmStudentList_Load(object sender, EventArgs e)
        {
            try
            {
                BindClass();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            try
            {
                //if (cmbClass.SelectedIndex == 0 && cmbSection.SelectedIndex == 0)
                //{
                //    MessageBox.Show("Please select Class and Section !!");
                //    return;
                //}
                string Active = chkActive.Checked == true ? "1" : "0";
                cry_StudentList cry = new cry_StudentList();
                frm_DisplayReport frm = new frm_DisplayReport();
                sql = "";
                sql += "                 select Admission.*,class_mas.cname as ClassName, section_mas.sname as SectionName from Admission inner join class_mas on Admission.Class=class_mas.cid";
                sql += " INNER JOIN section_mas on Admission.Section=section_mas.sid";
                sql += "  where IsActive=" + Active + "";
                if (cmbClass.SelectedIndex > 0 && cmbSection.SelectedIndex > 0)
                {
                    sql += "  and Admission.Class='" + cmbClass.SelectedValue + "' and Admission.Section='" + cmbSection.SelectedValue + "'";
                }
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    cry.SetDataSource(dt);
                    cry.SetParameterValue("Session", DataHelper.FinYear);
                    cry.SetParameterValue("SchoolName", dh.getSchoolDetails().Rows[0]["SchoolName"].ToString());
                    cry.SetParameterValue("Address", dh.getSchoolDetails().Rows[0]["Address"].ToString());
                    frm.crystalReportViewer1.ReportSource = cry;
                    frm.crystalReportViewer1.Refresh();
                    frm.Show();
                }
                else
                {
                    MessageBox.Show("Data Not found !!");
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void cmbClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbClass.SelectedIndex > 0)
            {
                BindSection();
            }
        }
    }
}
