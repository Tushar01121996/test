﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmRegistration : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmRegistration()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        public void BindClasses()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);

            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);

            cmbclass.DataSource = dt;
            cmbclass.DisplayMember = "cname";
            cmbclass.ValueMember = "cid";


        }
        public void BindPclasses()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);

            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);

            cmbpclass.DataSource = dt;
            cmbpclass.DisplayMember = "cname";
            cmbpclass.ValueMember = "cid";
        }
        public void clearcontrols()
        {
            txtcadd.Text = "";
            txtpadd.Text = "";
            txtmob.Text = "";
            txtemail.Text = "";
            txtpincode.Text = "";
            txtpschool.Text = "";
            cmbcity.Text = "";
            cmbstate.Text = "";
            cmbcountry.Text = "";
            txtfname.Text = "";
            txtmname.Text = "";
            txtname.Text = "";
            txtguardian.Text = "";
            cmbresult.Text = "";
            cmbgender.Text = "";
            cmbRelation.Text = "";
            if (cmbclass.SelectedIndex > 0)
                cmbclass.SelectedIndex = 0;
            if (cmbpclass.SelectedIndex > 0)
                cmbpclass.SelectedIndex = 0;
        }
        private void frmRegistration_Load(object sender, EventArgs e)
        {
            try
            {
                btnAdd.Focus();
                getRegNo();
                clearcontrols();
                BindClasses();
                BindPclasses();
                panel2.Enabled = false;
                panel3.Enabled = false;
                BindGrid();

            }
            catch (Exception ex)
            {

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void getRegNo()
        {
            sql = "select isnull(max(isnull(substring(RegNo,3,7),0)),0) + 1 from Registration";
            dt = dh.DataTable(sql);
            if (dt.Rows.Count > 0)
            {
                txtRegNo.Text = "RG" + dt.Rows[0][0].ToString();
            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtname.Text))
                {
                    MessageBox.Show("Please Enter Name..");
                    return;
                }
                string RegNo = txtRegNo.Text;
                sql = "select * from Registration where RegNo='" + RegNo + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    //Update
                    //sql = "select * from Admission where RegNo='" + txtRegNo.Text + "'";
                    //dt = dh.DataTable(sql);
                    //if (dt.Rows.Count > 0)
                    //{
                    //    MessageBox.Show("Student can not Update !!");
                    //    return;
                    //}
                    sql = "";
                    sql += " update Registration set ";
                    sql += " Dob= '" + dtpdob.Value.ToString("yyyy-MM-dd") + "'";
                    sql += ",Name='" + txtname.Text + "'";
                    sql += ",Class='" + cmbclass.SelectedValue + "'";
                    sql += ",Gender='" + cmbgender.Text + "'";
                    sql += ",Fname='" + txtfname.Text + "'";
                    sql += ",Mname='" + txtmname.Text + "'";
                    sql += ",Guardian='" + txtguardian.Text + "'";
                    sql += ",Relation='" + cmbRelation.Text + "'";
                    sql += ",PAdd='" + txtpadd.Text + "'";
                    sql += ",CAdd='" + txtcadd.Text + "'";
                    sql += ",Mobile='" + txtmob.Text + "'";
                    sql += ",Email='" + txtemail.Text + "'";
                    sql += ",PinCode='" + txtpincode.Text + "'";
                    sql += ",State='" + cmbstate.Text + "'";
                    sql += ",City='" + cmbcity.Text + "'";
                    sql += ",Country='" + cmbcountry.Text + "'";
                    sql += ",PClass='" + cmbpclass.SelectedValue + "'";
                    sql += ",Presult='" + cmbresult.Text + "'";
                    sql += ",PSchool='" + txtpschool.Text + "'";
                    sql += " Where RegNo='" + RegNo + "' and Finyear='" + DataHelper.FinYear + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Student Update Successfully !!");
                    panel2.Enabled = false;
                    panel3.Enabled = false;
                    BindGrid();
                }
                else
                {
                    //insert
                    sql = "";
                    sql += "insert into Registration (";
                    sql += "RegNo    ";
                    sql += ",RegDate  ";
                    sql += ",Dob      ";
                    sql += ",Name     ";
                    sql += ",Class    ";
                    sql += ",Gender   ";
                    sql += ",Fname    ";
                    sql += ",Mname    ";
                    sql += ",Guardian ";
                    sql += ",Relation ";
                    sql += ",PAdd     ";
                    sql += ",CAdd     ";
                    sql += ",Mobile   ";
                    sql += ",Email    ";
                    sql += ",Pincode  ";
                    sql += ",State    ";
                    sql += ",City    ";
                    sql += ",Country  ";
                    sql += ",PClass   ";
                    sql += ",PResult  ";
                    sql += ",PSchool  ";
                    sql += ",FinYear  ";
                    sql += ", UserId  ) ";
                    sql += "values  ( ";
                    sql += "'" + RegNo + "'";
                    sql += ",'" + dtpregdate.Value.ToString("yyyy-MM-dd") + "'";
                    sql += ",'" + dtpdob.Value.ToString("yyyy-MM-dd") + "'";
                    sql += ",'" + txtname.Text + "'";
                    sql += ",'" + cmbclass.SelectedValue + "'";
                    sql += ",'" + cmbgender.Text + "'";
                    sql += ",'" + txtfname.Text + "'";
                    sql += ",'" + txtmname.Text + "'";
                    sql += ",'" + txtguardian.Text + "'";
                    sql += ",'" + cmbRelation.Text + "'";
                    sql += ",'" + txtpadd.Text + "'";
                    sql += ",'" + txtcadd.Text + "'";
                    sql += ",'" + txtmob.Text + "'";
                    sql += ",'" + txtemail.Text + "'";
                    sql += ",'" + txtpincode.Text + "'";
                    sql += ",'" + cmbstate.Text + "'";
                    sql += ",'" + cmbcity.Text + "'";
                    sql += ",'" + cmbcountry.Text + "'";
                    sql += ",'" + cmbpclass.SelectedValue + "'";
                    sql += ",'" + cmbresult.Text + "'";
                    sql += ",'" + txtpschool.Text + "'";
                    sql += ",'" + DataHelper.FinYear + "'";
                    sql += ",'" + DataHelper.UserId + "')";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Student Successfully Registered !!");
                    panel2.Enabled = false;
                    panel3.Enabled = false;
                    BindGrid();

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void BindGrid()
        {
            sql = "select Registration.RegNo,Registration.Name,class_mas.cname as Class from Registration inner join class_mas on Registration.Class=class_mas.cid";
            dt = dh.DataTable(sql);
            dataGridView1.DataSource = dt;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            getRegNo();
            clearcontrols();
            panel2.Enabled = true;
            panel3.Enabled = true;
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            try
            {
                sql = "select * from Admission where RegNo='" + txtRegNo.Text + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Student can not delete !!");
                    return;
                }
                sql = "";
                sql += "delete from Registration where RegNo='" + txtRegNo.Text + "'";
                dh.ExecuteQuery(sql);
                MessageBox.Show("Student Successfully Deleted !!");
                panel2.Enabled = false;
                panel3.Enabled = false;
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                sql = "select * from Registration where RegNo='" + dataGridView1.CurrentRow.Cells[0].Value.ToString() + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    string clas = dt.Rows[0]["Class"].ToString();
                    string pclas = dt.Rows[0]["PClass"].ToString();
                    string RegNo = dt.Rows[0]["RegNo"].ToString();
                    string Name = dt.Rows[0]["Name"].ToString();
                    string dob = dt.Rows[0]["Dob"].ToString();
                    string regdate = dt.Rows[0]["RegDate"].ToString();
                    string fname = dt.Rows[0]["Fname"].ToString();
                    string mname = dt.Rows[0]["Mname"].ToString();
                    string guardian = dt.Rows[0]["Guardian"].ToString();
                    string relation = dt.Rows[0]["Relation"].ToString();
                    string padd = dt.Rows[0]["PAdd"].ToString();
                    string cadd = dt.Rows[0]["CAdd"].ToString();
                    string mob = dt.Rows[0]["Mobile"].ToString();
                    string email = dt.Rows[0]["Email"].ToString();
                    string pincode = dt.Rows[0]["Pincode"].ToString();
                    string state = dt.Rows[0]["State"].ToString();
                    string city = dt.Rows[0]["City"].ToString();
                    string country = dt.Rows[0]["Country"].ToString();
                    string presult = dt.Rows[0]["PResult"].ToString();
                    string pschool = dt.Rows[0]["PSchool"].ToString();
                    string gender = dt.Rows[0]["Gender"].ToString();

                    txtRegNo.Text = RegNo;
                    cmbcity.Text = city;
                    cmbstate.Text = state;
                    cmbcountry.Text = country;
                    cmbclass.SelectedValue = clas;
                    cmbpclass.SelectedValue = pclas;
                    cmbresult.Text = presult;
                    cmbRelation.Text = relation;
                    txtmob.Text = mob;
                    txtemail.Text = email;
                    txtpincode.Text = pincode;
                    txtpadd.Text = padd;
                    txtcadd.Text = cadd;
                    txtpschool.Text = pschool;
                    txtname.Text = Name;
                    txtfname.Text = fname;
                    txtmname.Text = mname;
                    txtguardian.Text = guardian;
                    cmbgender.Text = gender;
                    dtpdob.Value = Convert.ToDateTime(dob);
                    dtpregdate.Value = Convert.ToDateTime(regdate);
                }

                panel2.Enabled = true;
                panel3.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sql = "select Registration.RegNo,Registration.Name,class_mas.cname as Class from Registration inner join class_mas on Registration.Class=class_mas.cid where Registration.Name like '%" + txtsearch.Text + "%'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            getRegNo();
            clearcontrols();
            panel2.Enabled = false;
            panel3.Enabled = false;
        }
    }
}
