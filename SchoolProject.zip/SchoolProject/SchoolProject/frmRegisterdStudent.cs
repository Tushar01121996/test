﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmRegisterdStudent : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmRegisterdStudent()
        {
            InitializeComponent();
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);
            cmbClass.DataSource = dt;

            cmbClass.DisplayMember = "cname";
            cmbClass.ValueMember = "cid";
        }
        public void BindSection()
        {
            cmbSection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbClass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbSection.DataSource = dt;

            cmbSection.DisplayMember = "sname";
            cmbSection.ValueMember = "sid";
        }
        private void btnShow_Click(object sender, EventArgs e)
        {
            try
            {

                cry_RegisteredList cry = new cry_RegisteredList();
                frm_DisplayReport frm = new frm_DisplayReport();
                sql = "";
                sql += "              select Registration.*,class_mas.cname as ClassName from Registration inner join class_mas on Registration.Class=class_mas.cid";
                sql += " where Registration.RegNo not in (select RegNo from Admission)";
                if (cmbClass.SelectedIndex > 0)
                {
                    sql += " and Registration.Class='" + cmbClass.SelectedValue + "' ";
                }
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    string clas = cmbClass.SelectedIndex > 0 ? cmbClass.Text : "All";
                    cry.SetDataSource(dt);
                    cry.SetParameterValue("Session", DataHelper.FinYear);
                    cry.SetParameterValue("SchoolName", dh.getSchoolDetails().Rows[0]["SchoolName"].ToString());
                    cry.SetParameterValue("Address", dh.getSchoolDetails().Rows[0]["Address"].ToString());
                    cry.SetParameterValue("Class", clas);
                    frm.crystalReportViewer1.ReportSource = cry;
                    frm.crystalReportViewer1.Refresh();
                    frm.Show();
                }
                else
                {
                    MessageBox.Show("Data Not found !!");
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void cmbClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbClass.SelectedIndex > 0)
            {
                //BindSection();
                sql = "";
                sql += "              select Registration.RegNo,Registration.Name,Registration.Fname,Registration.Mobile,class_mas.cname as Class from Registration inner join class_mas on Registration.Class=class_mas.cid";
                sql += " where Registration.RegNo not in (select RegNo from Admission) and Registration.Class='" + cmbClass.SelectedValue + "'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;

                lblCount.Text = "Count : " + dt.Rows.Count.ToString();
            }
        }

        private void frmRegisterdStudent_Load(object sender, EventArgs e)
        {
            try
            {
                lblCount.Text = string.Empty;
                BindClass();
                string sql1 = string.Empty;
                DataTable dt1 = new DataTable();
                sql1 = "";
                sql1 += "              select Registration.RegNo,Registration.Name,Registration.Fname,Registration.Mobile,class_mas.cname as Class from Registration inner join class_mas on Registration.Class=class_mas.cid";
                sql1 += " where Registration.RegNo not in (select RegNo from Admission)";
                dt1 = dh.DataTable(sql1);
                dataGridView1.DataSource = dt1;

                lblCount.Text = "Count : " + dt1.Rows.Count.ToString(); 

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
