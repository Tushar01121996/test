﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmAdmission : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        string StuId = string.Empty;
        public frmAdmission()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        public void BindSection()
        {
            cmbSection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbclass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbSection.DataSource = dt;

            cmbSection.DisplayMember = "sname";
            cmbSection.ValueMember = "sid";
        }
        public void BindClasses()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);

            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);

            cmbclass.DataSource = dt;
            cmbclass.DisplayMember = "cname";
            cmbclass.ValueMember = "cid";


        }
        public void BindPclasses()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);

            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);

            cmbpclass.DataSource = dt;
            cmbpclass.DisplayMember = "cname";
            cmbpclass.ValueMember = "cid";
        }
        public void clearcontrols()
        {
            StuId = "";
            txtcadd.Text = "";
            txtpadd.Text = "";
            txtmob.Text = "";
            txtemail.Text = "";
            txtpincode.Text = "";
            txtpschool.Text = "";
            cmbcity.Text = "";
            cmbstate.Text = "";
            cmbcountry.Text = "";
            txtfname.Text = "";
            txtmname.Text = "";
            txtname.Text = "";
            txtguardian.Text = "";
            cmbresult.Text = "";
            cmbgender.Text = "";
            cmbRelation.Text = "";
            if (cmbclass.SelectedIndex > 0)
                cmbclass.SelectedIndex = 0;
            if (cmbpclass.SelectedIndex > 0)
                cmbpclass.SelectedIndex = 0;
            if (cmbSection.SelectedIndex > 0)
                cmbSection.SelectedIndex = 0;
            cmbRegNo.Text = "";
            chkActive.Checked = false;
            chkIsNew.Checked = false;
        }
        private void frmAdmission_Load(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void getAdmNo()
        {
            sql = "select isnull(max(isnull(substring(AdmNo,3,7),0)),0) + 1 from Admission";
            dt = dh.DataTable(sql);
            if (dt.Rows.Count > 0)
            {
                txtAdmNo.Text = "AD" + dt.Rows[0][0].ToString();
                StuId = "ST" + dt.Rows[0][0].ToString();
            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtname.Text))
                {
                    MessageBox.Show("Please Enter Name..");
                    return;
                }
                if (string.IsNullOrEmpty(cmbRegNo.Text))
                {
                    MessageBox.Show("Please Select Registration No..");
                    return;
                }
                string RegNo = cmbRegNo.Text;
                sql = "select * from Registration where RegNo='" + RegNo + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Student Not Registered !!");
                    return;
                }

                sql = "select * from Admission where RegNo='" + RegNo + "'";
                dt = dh.DataTable(sql);
                string isnew = chkIsNew.Checked == true ? "1" : "0";
                string Active = chkActive.Checked == true ? "1" : "0";
                string BusFee = chkBusFeeAllow.Checked == true ? "1" : "0";
                if (dt.Rows.Count > 0)
                {
                    //Update
                    //sql = "select * from Admission where RegNo='" + txtRegNo.Text + "'";
                    //dt = dh.DataTable(sql);
                    //if (dt.Rows.Count > 0)
                    //{
                    //    MessageBox.Show("Student can not Update !!");
                    //    return;
                    //}
                    sql = "";
                    sql += " update Admission set ";
                    sql += " Dob= '" + dtpdob.Value.ToString("yyyy-MM-dd") + "'";
                    sql += ",Name='" + txtname.Text + "'";
                    sql += ",Class='" + cmbclass.SelectedValue + "'";
                    sql += ",Gender='" + cmbgender.Text + "'";
                    sql += ",Fname='" + txtfname.Text + "'";
                    sql += ",Mname='" + txtmname.Text + "'";
                    sql += ",Guardian='" + txtguardian.Text + "'";
                    sql += ",Relation='" + cmbRelation.Text + "'";
                    sql += ",PAdd='" + txtpadd.Text + "'";
                    sql += ",CAdd='" + txtcadd.Text + "'";
                    sql += ",Mobile='" + txtmob.Text + "'";
                    sql += ",Email='" + txtemail.Text + "'";
                    sql += ",PinCode='" + txtpincode.Text + "'";
                    sql += ",State='" + cmbstate.Text + "'";
                    sql += ",City='" + cmbcity.Text + "'";
                    sql += ",Country='" + cmbcountry.Text + "'";
                    sql += ",PClass='" + cmbpclass.SelectedValue + "'";
                    sql += ",Presult='" + cmbresult.Text + "'";
                    sql += ",PSchool='" + txtpschool.Text + "'";
                    sql += ",IsNew='" + isnew + "'";
                    sql += ",IsActive='" + Active + "'";
                    sql += ",Section='" + cmbSection.SelectedValue + "'";
                    sql += ",BusFee='" + BusFee + "'";
                    sql += " Where AdmNo='" + txtAdmNo.Text + "' and StuId='" + StuId + "' and Finyear='" + DataHelper.FinYear + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Student Update Successfully !!");
                    panel2.Enabled = false;
                    panel3.Enabled = false;
                    BindGrid();
                }
                else
                {
                    //insert
                    sql = "";
                    sql += "insert into Admission (";
                    sql += "RegNo    ";
                    sql += ",AdmNo  ";
                    sql += ",StuId  ";
                    sql += ",RegDate  ";
                    sql += ",Dob      ";
                    sql += ",Name     ";
                    sql += ",Class    ";
                    sql += ",Gender   ";
                    sql += ",Fname    ";
                    sql += ",Mname    ";
                    sql += ",Guardian ";
                    sql += ",Relation ";
                    sql += ",PAdd     ";
                    sql += ",CAdd     ";
                    sql += ",Mobile   ";
                    sql += ",Email    ";
                    sql += ",Pincode  ";
                    sql += ",State    ";
                    sql += ",City    ";
                    sql += ",Country  ";
                    sql += ",PClass   ";
                    sql += ",PResult  ";
                    sql += ",PSchool  ";
                    sql += ",IsNew  ";
                    sql += ",IsActive  ";
                    sql += ",FinYear  ";
                    sql += ", UserId,Section,BusFee  ) ";
                    sql += "values  ( ";
                    sql += "'" + RegNo + "'";
                    sql += ",'" + txtAdmNo.Text + "'";
                    sql += ",'" + StuId.ToString() + "'";
                    sql += ",'" + dtpregdate.Value.ToString("yyyy-MM-dd") + "'";
                    sql += ",'" + dtpdob.Value.ToString("yyyy-MM-dd") + "'";
                    sql += ",'" + txtname.Text + "'";
                    sql += ",'" + cmbclass.SelectedValue + "'";
                    sql += ",'" + cmbgender.Text + "'";
                    sql += ",'" + txtfname.Text + "'";
                    sql += ",'" + txtmname.Text + "'";
                    sql += ",'" + txtguardian.Text + "'";
                    sql += ",'" + cmbRelation.Text + "'";
                    sql += ",'" + txtpadd.Text + "'";
                    sql += ",'" + txtcadd.Text + "'";
                    sql += ",'" + txtmob.Text + "'";
                    sql += ",'" + txtemail.Text + "'";
                    sql += ",'" + txtpincode.Text + "'";
                    sql += ",'" + cmbstate.Text + "'";
                    sql += ",'" + cmbcity.Text + "'";
                    sql += ",'" + cmbcountry.Text + "'";
                    sql += ",'" + cmbpclass.SelectedValue + "'";
                    sql += ",'" + cmbresult.Text + "'";
                    sql += ",'" + txtpschool.Text + "'";
                    sql += ",'" + isnew + "'";
                    sql += ",'" + Active + "'";
                    sql += ",'" + DataHelper.FinYear + "'";
                    sql += ",'" + DataHelper.UserId + "','" + cmbSection.SelectedValue + "','" + BusFee + "')";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Student Admission Successfully !!");
                    panel2.Enabled = false;
                    panel3.Enabled = false;
                    BindGrid();

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void BindGrid()
        {
            sql = "select Admission.AdmNo,Admission.Name,class_mas.cname as Class from Admission inner join class_mas on Admission.Class=class_mas.cid";
            dt = dh.DataTable(sql);
            dataGridView1.DataSource = dt;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            clearcontrols();
            getAdmNo();
            BindRegNo();
            panel2.Enabled = true;
            panel3.Enabled = true;
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            try
            {
                //sql = "select * from Admission where AdmNo='" + txtAdmNo.Text + "'";
                //dt = dh.DataTable(sql);
                //if (dt.Rows.Count > 0)
                //{
                //    MessageBox.Show("Student can not delete !!");
                //    return;
                //}
                sql = "select * from Fee_RecMain where StuId='" + StuId + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Fees has been recieed ,So it can't be delete!!");
                    return;
                }
                sql = "";
                sql += "delete from Admission where AdmNo='" + txtAdmNo.Text + "' and StuId='" + StuId + "'";
                dh.ExecuteQuery(sql);
                MessageBox.Show("Student Successfully Deleted !!");
                panel2.Enabled = false;
                panel3.Enabled = false;
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void BindRegNo()
        {
            cmbRegNo.Items.Clear();
            sql = "select RegNo from Registration where RegNo not in (select RegNo from Admission)";
            dt = dh.DataTable(sql);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    cmbRegNo.Items.Add(dt.Rows[i]["RegNo"].ToString());
                }
            }
        }
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                sql = "select * from Admission where AdmNo='" + dataGridView1.CurrentRow.Cells[0].Value.ToString() + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    string clas = dt.Rows[0]["Class"].ToString();
                    string pclas = dt.Rows[0]["PClass"].ToString();
                    string AdmNo = dt.Rows[0]["AdmNo"].ToString();
                    string RegNo = dt.Rows[0]["RegNo"].ToString();
                    string Stuid = dt.Rows[0]["StuId"].ToString();
                    string Name = dt.Rows[0]["Name"].ToString();
                    string dob = dt.Rows[0]["Dob"].ToString();
                    string regdate = dt.Rows[0]["RegDate"].ToString();
                    string fname = dt.Rows[0]["Fname"].ToString();
                    string mname = dt.Rows[0]["Mname"].ToString();
                    string guardian = dt.Rows[0]["Guardian"].ToString();
                    string relation = dt.Rows[0]["Relation"].ToString();
                    string padd = dt.Rows[0]["PAdd"].ToString();
                    string cadd = dt.Rows[0]["CAdd"].ToString();
                    string mob = dt.Rows[0]["Mobile"].ToString();
                    string email = dt.Rows[0]["Email"].ToString();
                    string pincode = dt.Rows[0]["Pincode"].ToString();
                    string state = dt.Rows[0]["State"].ToString();
                    string city = dt.Rows[0]["City"].ToString();
                    string country = dt.Rows[0]["Country"].ToString();
                    string presult = dt.Rows[0]["PResult"].ToString();
                    string pschool = dt.Rows[0]["PSchool"].ToString();
                    string gender = dt.Rows[0]["Gender"].ToString();
                    string isnew = dt.Rows[0]["IsNew"].ToString();
                    string Active = dt.Rows[0]["IsActive"].ToString();
                    string Section = dt.Rows[0]["Section"].ToString();
                    string BusFee = dt.Rows[0]["BusFee"].ToString();

                    txtAdmNo.Text = AdmNo;
                    cmbRegNo.Text = RegNo;
                    StuId = Stuid;
                    cmbcity.Text = city;
                    cmbstate.Text = state;
                    cmbcountry.Text = country;
                    cmbclass.SelectedValue = clas;
                    cmbpclass.SelectedValue = pclas;
                    cmbresult.Text = presult;
                    cmbRelation.Text = relation;
                    txtmob.Text = mob;
                    txtemail.Text = email;
                    txtpincode.Text = pincode;
                    txtpadd.Text = padd;
                    txtcadd.Text = cadd;
                    txtpschool.Text = pschool;
                    txtname.Text = Name;
                    txtfname.Text = fname;
                    txtmname.Text = mname;
                    txtguardian.Text = guardian;
                    cmbgender.Text = gender;
                    dtpdob.Value = Convert.ToDateTime(dob);
                    dtpregdate.Value = Convert.ToDateTime(regdate);
                    cmbSection.SelectedValue = Section;
                    if (isnew == "1")
                    {
                        chkIsNew.Checked = true;
                    }
                    else
                    {
                        chkIsNew.Checked = false;
                    }
                    if (Active == "1")
                    {
                        chkActive.Checked = true;
                    }
                    else
                    {
                        chkActive.Checked = false;
                    }
                    if (BusFee == "1")
                    {
                        chkBusFeeAllow.Checked = true;
                    }
                    else
                    {
                        chkBusFeeAllow.Checked = false;
                    }
                }

                panel2.Enabled = true;
                panel3.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sql = "select Admission.RegNo,Admission.Name,class_mas.cname as Class from Admission inner join class_mas on Admission.Class=class_mas.cid where Admission.Name like '%" + txtsearch.Text + "%'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void frmAdmission_Load_1(object sender, EventArgs e)
        {
            //BindRegNo();
            btnAdd.Focus();
            getAdmNo();
            clearcontrols();
            BindClasses();
            BindPclasses();
            panel2.Enabled = false;
            panel3.Enabled = false;
            BindGrid();
            BindRegNo();

        }

        private void cmbRegNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(cmbRegNo.Text))
                {
                    sql = "select * from Registration where RegNo='" + cmbRegNo.SelectedItem.ToString() + "'";
                    dt = dh.DataTable(sql);
                    if (dt.Rows.Count > 0)
                    {
                        string clas = dt.Rows[0]["Class"].ToString();
                        string pclas = dt.Rows[0]["PClass"].ToString();
                        string RegNo = dt.Rows[0]["RegNo"].ToString();
                        string Name = dt.Rows[0]["Name"].ToString();
                        string dob = dt.Rows[0]["Dob"].ToString();
                        string regdate = dt.Rows[0]["RegDate"].ToString();
                        string fname = dt.Rows[0]["Fname"].ToString();
                        string mname = dt.Rows[0]["Mname"].ToString();
                        string guardian = dt.Rows[0]["Guardian"].ToString();
                        string relation = dt.Rows[0]["Relation"].ToString();
                        string padd = dt.Rows[0]["PAdd"].ToString();
                        string cadd = dt.Rows[0]["CAdd"].ToString();
                        string mob = dt.Rows[0]["Mobile"].ToString();
                        string email = dt.Rows[0]["Email"].ToString();
                        string pincode = dt.Rows[0]["Pincode"].ToString();
                        string state = dt.Rows[0]["State"].ToString();
                        string city = dt.Rows[0]["City"].ToString();
                        string country = dt.Rows[0]["Country"].ToString();
                        string presult = dt.Rows[0]["PResult"].ToString();
                        string pschool = dt.Rows[0]["PSchool"].ToString();
                        string gender = dt.Rows[0]["Gender"].ToString();
                        //string Section = dt.Rows[0]["Section"].ToString();
                        //string BusFee = dt.Rows[0]["BusFee"].ToString();


                        cmbcity.Text = city;
                        cmbstate.Text = state;
                        cmbcountry.Text = country;
                        cmbclass.SelectedValue = clas;
                        cmbpclass.SelectedValue = pclas;
                        cmbresult.Text = presult;
                        cmbRelation.Text = relation;
                        txtmob.Text = mob;
                        txtemail.Text = email;
                        txtpincode.Text = pincode;
                        txtpadd.Text = padd;
                        txtcadd.Text = cadd;
                        txtpschool.Text = pschool;
                        txtname.Text = Name;
                        txtfname.Text = fname;
                        txtmname.Text = mname;
                        txtguardian.Text = guardian;
                        cmbgender.Text = gender;
                        dtpdob.Value = Convert.ToDateTime(dob);
                        dtpregdate.Value = Convert.ToDateTime(regdate);
                       // cmbSection.SelectedValue = Section;
                    }

                    panel2.Enabled = true;
                    panel3.Enabled = true;
                    //BindClasses();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            getAdmNo();
            clearcontrols();
            panel2.Enabled = false;
            panel3.Enabled = false;
        }

        private void cmbclass_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindSection();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
