﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmSchoolSettings : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmSchoolSettings()
        {
            InitializeComponent();
        }

        private void frmStudentList_Load(object sender, EventArgs e)
        {
            try
            {
                //txtSchoolname.Text = dh.ComputerName();
                //clearcontrols();
                sql = "select * from SchoolSettings";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    txtadd.Text = dt.Rows[0]["Address"].ToString();
                    txtmob.Text = dt.Rows[0]["Mobile"].ToString();
                    txtstate.Text = dt.Rows[0]["State"].ToString();
                    txtcity.Text = dt.Rows[0]["City"].ToString();
                    txtpincode.Text = dt.Rows[0]["PinCode"].ToString();
                    txtSchoolname.Text = dt.Rows[0]["SchoolName"].ToString();
                    txtemail.Text = dt.Rows[0]["Email"].ToString();
                    txtcountry.Text = dt.Rows[0]["Country"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            try
            {
                sql = "select * from SchoolSettings";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    sql = "update SchoolSettings set SchoolName='" + txtSchoolname.Text + "',Address='" + txtadd.Text + "',Mobile='" + txtmob.Text + "',Country='" + txtcountry.Text + "',State='" + txtstate.Text + "',City='" + txtcity.Text + "',PinCode='" + txtpincode.Text + "',Email='" + txtemail.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Update Successfully !!");
                }
                else
                {
                    sql = "insert into SchoolSettings(SchoolName,Address,Mobile,Country,State,City,PinCode,Email)values('" + txtSchoolname.Text + "','" + txtadd.Text + "','" + txtmob.Text + "','" + txtcountry.Text + "','" + txtstate.Text + "','" + txtcity.Text + "','" + txtpincode.Text + "','" + txtemail.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Save Successfully !!");
                }
                pnl.Enabled = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void clearcontrols()
        {
            txtemail.Text = "";
            txtmob.Text = "";
            txtpincode.Text = "";
            txtSchoolname.Text = "";
            txtcity.Text = "";
            txtstate.Text = "";
            txtadd.Text = "";
           
        }

        private void cmbClass_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbStudents_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbSection_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
