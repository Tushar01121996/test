﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmDefaulter : Form
    {
        DataHelper dh = new DataHelper();
        string sql = string.Empty;
        DataTable dt = new DataTable();
        public frmDefaulter()
        {
            InitializeComponent();
        }
        //select * from feesHead
        private void btnShow_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbFeesHead.SelectedIndex == 0)
                {
                    MessageBox.Show("Please Select Fees Head !!");
                    return;
                }
                if (string.IsNullOrEmpty(cmbMonth.Text))
                {
                    MessageBox.Show("Please Select Month !!");
                    return;
                }
                string defaulter = chkDefaulter.Checked == true ? "not" : "";
                sql = "";
                sql += "                select a.Name,a.Fname,a.Mobile" + Environment.NewLine;
                sql += " ,(select Amount from FeesMaster where class='" + cmbclass.SelectedValue + "' and Section='" + cmbsection.SelectedValue + "' and Month='" + cmbMonth.Text + "' and FeesHead='" + cmbFeesHead.SelectedValue + "') as Amount" + Environment.NewLine;
                sql += "  from admission a where StuId " + defaulter + " in (select StuId from Fee_RecDtl where Month='" + cmbMonth.Text + "' and FeesHead='" + cmbFeesHead.Text + "') and class='" + cmbclass.SelectedValue + "' and Section='" + cmbsection.SelectedValue + "'" + Environment.NewLine;
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    dataGridView1.DataSource = dt;
                    dataGridView1.Columns[0].Width = 230;
                    dataGridView1.Columns[1].Width = 230;
                }
                else
                {
                    MessageBox.Show("No Record Found !!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                cry_DefaulterReprot cry = new cry_DefaulterReprot();
                frm_DisplayReport frm = new frm_DisplayReport();
                if (cmbFeesHead.SelectedIndex == 0)
                {
                    MessageBox.Show("Please Select Class !!");
                    return;
                }
                if (string.IsNullOrEmpty(cmbMonth.Text))
                {
                    MessageBox.Show("Please Select Month !!");
                    return;
                }
                string defaulter = chkDefaulter.Checked == true ? "not" : "";
                string reportHeader = chkDefaulter.Checked == true ? "Defaulter Report" : "Fee Submitted Students";
                sql = "";
                sql += "                select a.Name,a.Fname,a.Mobile" + Environment.NewLine;
                sql += " ,(select Amount from FeesMaster where class='" + cmbclass.SelectedValue + "' and Section='" + cmbsection.SelectedValue + "' and Month='" + cmbMonth.Text + "' and FeesHead='" + cmbFeesHead.SelectedValue + "') as Amount" + Environment.NewLine;
                sql += "  from admission a where StuId  " + defaulter + " in(select StuId from Fee_RecDtl where Month='" + cmbMonth.Text + "' and FeesHead='" + cmbFeesHead.Text + "') and class='" + cmbclass.SelectedValue + "' and Section='" + cmbsection.SelectedValue + "'" + Environment.NewLine;
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    string clas = cmbclass.Text;
                    string section = cmbsection.Text;
                    string month = cmbMonth.Text;

                    cry.SetDataSource(dt);
                    cry.SetParameterValue("Class", clas);
                    cry.SetParameterValue("Section", section);
                    cry.SetParameterValue("Session", DataHelper.FinYear);
                    cry.SetParameterValue("Month", month);
                    cry.SetParameterValue("SchoolName", dh.getSchoolDetails().Rows[0]["SchoolName"].ToString());
                    cry.SetParameterValue("Address", dh.getSchoolDetails().Rows[0]["Address"].ToString());
                    cry.SetParameterValue("ReportHeader", reportHeader);
                    frm.crystalReportViewer1.ReportSource = cry;
                    frm.crystalReportViewer1.Refresh();
                    frm.Show();
                }
                else
                {
                    MessageBox.Show("No Record Found !!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void BindFeesHead()
        {
            sql = "select HeadId,HeadName from FeesHead";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Fees Head--";
            dt.Rows.InsertAt(row, 0);
            cmbFeesHead.DataSource = dt;

            cmbFeesHead.DisplayMember = "HeadName";
            cmbFeesHead.ValueMember = "HeadId";
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);
            cmbclass.DataSource = dt;

            cmbclass.DisplayMember = "cname";
            cmbclass.ValueMember = "cid";
        }
        public void BindSection()
        {
            cmbsection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbclass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbsection.DataSource = dt;

            cmbsection.DisplayMember = "sname";
            cmbsection.ValueMember = "sid";
        }
        private void frmDefaulter_Load(object sender, EventArgs e)
        {
            BindClass();
            BindFeesHead();
        }

        private void cmbclass_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindSection();
        }
    }
}
