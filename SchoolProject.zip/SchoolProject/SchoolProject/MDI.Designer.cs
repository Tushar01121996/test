﻿namespace SchoolProject
{
    partial class MDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDI));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.masterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sectionMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classSectionManageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.feesHeadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expenseHeadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feesMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feeAllotmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentRegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentAdmissionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.studentListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentRegistrationListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.admitCardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.admitCardToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feeRecieptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expenseTransactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acessoriesDistributionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.defauterReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dueReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tCOthersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.characterCertificateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.birthCertificateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transferCertificateTCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bonafiedCertificateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.sMSTemplatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sendSMSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.schoolSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.financialYearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.notePadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excelSheetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.securityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterToolStripMenuItem,
            this.studentsToolStripMenuItem,
            this.transactionToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.tCOthersToolStripMenuItem,
            this.toolStripMenuItem2,
            this.toolsToolStripMenuItem,
            this.securityToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(632, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // masterToolStripMenuItem
            // 
            this.masterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.classMasterToolStripMenuItem,
            this.sectionMasterToolStripMenuItem,
            this.classSectionManageToolStripMenuItem,
            this.toolStripSeparator3,
            this.feesHeadToolStripMenuItem,
            this.expenseHeadToolStripMenuItem,
            this.feesMasterToolStripMenuItem,
            this.feeAllotmentToolStripMenuItem,
            this.toolStripSeparator4,
            this.accessoriesToolStripMenuItem});
            this.masterToolStripMenuItem.Name = "masterToolStripMenuItem";
            this.masterToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.masterToolStripMenuItem.Text = "Master";
            // 
            // classMasterToolStripMenuItem
            // 
            this.classMasterToolStripMenuItem.Name = "classMasterToolStripMenuItem";
            this.classMasterToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.classMasterToolStripMenuItem.Text = "Class Master";
            this.classMasterToolStripMenuItem.Click += new System.EventHandler(this.classMasterToolStripMenuItem_Click);
            // 
            // sectionMasterToolStripMenuItem
            // 
            this.sectionMasterToolStripMenuItem.Name = "sectionMasterToolStripMenuItem";
            this.sectionMasterToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.sectionMasterToolStripMenuItem.Text = "Section Master";
            this.sectionMasterToolStripMenuItem.Click += new System.EventHandler(this.sectionMasterToolStripMenuItem_Click);
            // 
            // classSectionManageToolStripMenuItem
            // 
            this.classSectionManageToolStripMenuItem.Name = "classSectionManageToolStripMenuItem";
            this.classSectionManageToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.classSectionManageToolStripMenuItem.Text = "Class Section Manage";
            this.classSectionManageToolStripMenuItem.Click += new System.EventHandler(this.classSectionManageToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(186, 6);
            // 
            // feesHeadToolStripMenuItem
            // 
            this.feesHeadToolStripMenuItem.Name = "feesHeadToolStripMenuItem";
            this.feesHeadToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.feesHeadToolStripMenuItem.Text = "Fees Head";
            this.feesHeadToolStripMenuItem.Click += new System.EventHandler(this.feesHeadToolStripMenuItem_Click);
            // 
            // expenseHeadToolStripMenuItem
            // 
            this.expenseHeadToolStripMenuItem.Name = "expenseHeadToolStripMenuItem";
            this.expenseHeadToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.expenseHeadToolStripMenuItem.Text = "Expense Head";
            this.expenseHeadToolStripMenuItem.Click += new System.EventHandler(this.expenseHeadToolStripMenuItem_Click);
            // 
            // feesMasterToolStripMenuItem
            // 
            this.feesMasterToolStripMenuItem.Name = "feesMasterToolStripMenuItem";
            this.feesMasterToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.feesMasterToolStripMenuItem.Text = "Fees Master";
            this.feesMasterToolStripMenuItem.Click += new System.EventHandler(this.feesMasterToolStripMenuItem_Click);
            // 
            // feeAllotmentToolStripMenuItem
            // 
            this.feeAllotmentToolStripMenuItem.Name = "feeAllotmentToolStripMenuItem";
            this.feeAllotmentToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.feeAllotmentToolStripMenuItem.Text = "Fee Allotment";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(186, 6);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            this.accessoriesToolStripMenuItem.Click += new System.EventHandler(this.accessoriesToolStripMenuItem_Click);
            // 
            // studentsToolStripMenuItem
            // 
            this.studentsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentRegistrationToolStripMenuItem,
            this.studentAdmissionToolStripMenuItem,
            this.toolStripSeparator1,
            this.studentListToolStripMenuItem,
            this.studentRegistrationListToolStripMenuItem,
            this.toolStripSeparator2,
            this.admitCardToolStripMenuItem,
            this.admitCardToolStripMenuItem1});
            this.studentsToolStripMenuItem.Name = "studentsToolStripMenuItem";
            this.studentsToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.studentsToolStripMenuItem.Text = "Students";
            // 
            // studentRegistrationToolStripMenuItem
            // 
            this.studentRegistrationToolStripMenuItem.Name = "studentRegistrationToolStripMenuItem";
            this.studentRegistrationToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.studentRegistrationToolStripMenuItem.Text = "Student Registration";
            this.studentRegistrationToolStripMenuItem.Click += new System.EventHandler(this.studentRegistrationToolStripMenuItem_Click);
            // 
            // studentAdmissionToolStripMenuItem
            // 
            this.studentAdmissionToolStripMenuItem.Name = "studentAdmissionToolStripMenuItem";
            this.studentAdmissionToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.studentAdmissionToolStripMenuItem.Text = "Student Admission";
            this.studentAdmissionToolStripMenuItem.Click += new System.EventHandler(this.studentAdmissionToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(199, 6);
            // 
            // studentListToolStripMenuItem
            // 
            this.studentListToolStripMenuItem.Name = "studentListToolStripMenuItem";
            this.studentListToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.studentListToolStripMenuItem.Text = "Student List";
            this.studentListToolStripMenuItem.Click += new System.EventHandler(this.studentListToolStripMenuItem_Click);
            // 
            // studentRegistrationListToolStripMenuItem
            // 
            this.studentRegistrationListToolStripMenuItem.Name = "studentRegistrationListToolStripMenuItem";
            this.studentRegistrationListToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.studentRegistrationListToolStripMenuItem.Text = "Student Registration List";
            this.studentRegistrationListToolStripMenuItem.Click += new System.EventHandler(this.studentRegistrationListToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(199, 6);
            // 
            // admitCardToolStripMenuItem
            // 
            this.admitCardToolStripMenuItem.Name = "admitCardToolStripMenuItem";
            this.admitCardToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.admitCardToolStripMenuItem.Text = "Student Photo Upload";
            this.admitCardToolStripMenuItem.Click += new System.EventHandler(this.admitCardToolStripMenuItem_Click);
            // 
            // admitCardToolStripMenuItem1
            // 
            this.admitCardToolStripMenuItem1.Name = "admitCardToolStripMenuItem1";
            this.admitCardToolStripMenuItem1.Size = new System.Drawing.Size(202, 22);
            this.admitCardToolStripMenuItem1.Text = "Admit Card";
            this.admitCardToolStripMenuItem1.Click += new System.EventHandler(this.admitCardToolStripMenuItem1_Click);
            // 
            // transactionToolStripMenuItem
            // 
            this.transactionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.feeRecieptToolStripMenuItem,
            this.expenseTransactionToolStripMenuItem,
            this.acessoriesDistributionToolStripMenuItem});
            this.transactionToolStripMenuItem.Name = "transactionToolStripMenuItem";
            this.transactionToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.transactionToolStripMenuItem.Text = "Transaction";
            // 
            // feeRecieptToolStripMenuItem
            // 
            this.feeRecieptToolStripMenuItem.Name = "feeRecieptToolStripMenuItem";
            this.feeRecieptToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.feeRecieptToolStripMenuItem.Text = "Fee Reciept";
            this.feeRecieptToolStripMenuItem.Click += new System.EventHandler(this.feeRecieptToolStripMenuItem_Click);
            // 
            // expenseTransactionToolStripMenuItem
            // 
            this.expenseTransactionToolStripMenuItem.Name = "expenseTransactionToolStripMenuItem";
            this.expenseTransactionToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.expenseTransactionToolStripMenuItem.Text = "Expense Transaction";
            // 
            // acessoriesDistributionToolStripMenuItem
            // 
            this.acessoriesDistributionToolStripMenuItem.Name = "acessoriesDistributionToolStripMenuItem";
            this.acessoriesDistributionToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.acessoriesDistributionToolStripMenuItem.Text = "Acessories Distribution";
            this.acessoriesDistributionToolStripMenuItem.Click += new System.EventHandler(this.acessoriesDistributionToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.defauterReportToolStripMenuItem,
            this.dueReportToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.reportsToolStripMenuItem.Text = "Fees Reports";
            // 
            // defauterReportToolStripMenuItem
            // 
            this.defauterReportToolStripMenuItem.Name = "defauterReportToolStripMenuItem";
            this.defauterReportToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.defauterReportToolStripMenuItem.Text = "Defaulter Report";
            this.defauterReportToolStripMenuItem.Click += new System.EventHandler(this.defauterReportToolStripMenuItem_Click);
            // 
            // dueReportToolStripMenuItem
            // 
            this.dueReportToolStripMenuItem.Name = "dueReportToolStripMenuItem";
            this.dueReportToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.dueReportToolStripMenuItem.Text = "Fees Detail";
            this.dueReportToolStripMenuItem.Click += new System.EventHandler(this.dueReportToolStripMenuItem_Click);
            // 
            // tCOthersToolStripMenuItem
            // 
            this.tCOthersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.characterCertificateToolStripMenuItem,
            this.birthCertificateToolStripMenuItem,
            this.transferCertificateTCToolStripMenuItem,
            this.bonafiedCertificateToolStripMenuItem});
            this.tCOthersToolStripMenuItem.Name = "tCOthersToolStripMenuItem";
            this.tCOthersToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.tCOthersToolStripMenuItem.Text = "TC/Others";
            // 
            // characterCertificateToolStripMenuItem
            // 
            this.characterCertificateToolStripMenuItem.Name = "characterCertificateToolStripMenuItem";
            this.characterCertificateToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.characterCertificateToolStripMenuItem.Text = "Character Certificate";
            this.characterCertificateToolStripMenuItem.Click += new System.EventHandler(this.characterCertificateToolStripMenuItem_Click);
            // 
            // birthCertificateToolStripMenuItem
            // 
            this.birthCertificateToolStripMenuItem.Name = "birthCertificateToolStripMenuItem";
            this.birthCertificateToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.birthCertificateToolStripMenuItem.Text = "Birth Certificate";
            // 
            // transferCertificateTCToolStripMenuItem
            // 
            this.transferCertificateTCToolStripMenuItem.Name = "transferCertificateTCToolStripMenuItem";
            this.transferCertificateTCToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.transferCertificateTCToolStripMenuItem.Text = "Transfer Certificate(TC)";
            // 
            // bonafiedCertificateToolStripMenuItem
            // 
            this.bonafiedCertificateToolStripMenuItem.Name = "bonafiedCertificateToolStripMenuItem";
            this.bonafiedCertificateToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.bonafiedCertificateToolStripMenuItem.Text = "Bonafied Certificate";
            this.bonafiedCertificateToolStripMenuItem.Click += new System.EventHandler(this.bonafiedCertificateToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sMSTemplatesToolStripMenuItem,
            this.sendSMSToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(42, 20);
            this.toolStripMenuItem2.Text = "SMS";
            // 
            // sMSTemplatesToolStripMenuItem
            // 
            this.sMSTemplatesToolStripMenuItem.Name = "sMSTemplatesToolStripMenuItem";
            this.sMSTemplatesToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.sMSTemplatesToolStripMenuItem.Text = "SMS Templates";
            this.sMSTemplatesToolStripMenuItem.Click += new System.EventHandler(this.sMSTemplatesToolStripMenuItem_Click);
            // 
            // sendSMSToolStripMenuItem
            // 
            this.sendSMSToolStripMenuItem.Name = "sendSMSToolStripMenuItem";
            this.sendSMSToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.sendSMSToolStripMenuItem.Text = "Send SMS";
            this.sendSMSToolStripMenuItem.Click += new System.EventHandler(this.sendSMSToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.schoolSettingsToolStripMenuItem,
            this.financialYearToolStripMenuItem,
            this.toolStripMenuItem1,
            this.notePadToolStripMenuItem,
            this.calculatorToolStripMenuItem,
            this.excelSheetToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // schoolSettingsToolStripMenuItem
            // 
            this.schoolSettingsToolStripMenuItem.Name = "schoolSettingsToolStripMenuItem";
            this.schoolSettingsToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.schoolSettingsToolStripMenuItem.Text = "School Settings";
            this.schoolSettingsToolStripMenuItem.Click += new System.EventHandler(this.schoolSettingsToolStripMenuItem_Click);
            // 
            // financialYearToolStripMenuItem
            // 
            this.financialYearToolStripMenuItem.Name = "financialYearToolStripMenuItem";
            this.financialYearToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.financialYearToolStripMenuItem.Text = "Financial Year";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.toolStripMenuItem1.Text = "Create User";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // notePadToolStripMenuItem
            // 
            this.notePadToolStripMenuItem.Name = "notePadToolStripMenuItem";
            this.notePadToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.notePadToolStripMenuItem.Text = "NotePad";
            this.notePadToolStripMenuItem.Click += new System.EventHandler(this.notePadToolStripMenuItem_Click);
            // 
            // calculatorToolStripMenuItem
            // 
            this.calculatorToolStripMenuItem.Name = "calculatorToolStripMenuItem";
            this.calculatorToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.calculatorToolStripMenuItem.Text = "Calculator";
            this.calculatorToolStripMenuItem.Click += new System.EventHandler(this.calculatorToolStripMenuItem_Click);
            // 
            // excelSheetToolStripMenuItem
            // 
            this.excelSheetToolStripMenuItem.Name = "excelSheetToolStripMenuItem";
            this.excelSheetToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.excelSheetToolStripMenuItem.Text = "Excel Sheet";
            this.excelSheetToolStripMenuItem.Click += new System.EventHandler(this.excelSheetToolStripMenuItem_Click);
            // 
            // securityToolStripMenuItem
            // 
            this.securityToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backupToolStripMenuItem});
            this.securityToolStripMenuItem.Name = "securityToolStripMenuItem";
            this.securityToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.securityToolStripMenuItem.Text = "Security";
            // 
            // backupToolStripMenuItem
            // 
            this.backupToolStripMenuItem.Name = "backupToolStripMenuItem";
            this.backupToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.backupToolStripMenuItem.Text = "Backup";
            this.backupToolStripMenuItem.Click += new System.EventHandler(this.backupToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 431);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(632, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // MDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(632, 453);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MDI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MDI";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MDI_FormClosing);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem masterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sectionMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classSectionManageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feesHeadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expenseHeadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feesMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feeAllotmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentRegistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentAdmissionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feeRecieptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expenseTransactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem defauterReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dueReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem studentListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentRegistrationListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem admitCardToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem admitCardToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem tCOthersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem characterCertificateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem birthCertificateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transferCertificateTCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem schoolSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem financialYearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notePadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem excelSheetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem securityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bonafiedCertificateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem sMSTemplatesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sendSMSToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem acessoriesDistributionToolStripMenuItem;
    }
}



