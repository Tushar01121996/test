﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class Form1 : Form
    {
        string sql = string.Empty;
        DataTable dt = new DataTable();
        DataHelper dh = new DataHelper();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //DESKTOP-A7RURIK -- Tushar
                //DESKTOP-PDKJ2HU -- Sachin
                string computername = dh.ComputerName();
                if (computername == "DESKTOP-A7RURIK" || computername == "DESKTOP-PDKJ2HU")
                {
                    sql = "select * from tbl_userinfo";
                    dt = dh.DataTable(sql);
                    if (dt.Rows.Count > 0)
                    {
                        cmbUsername.DataSource = dt;
                        cmbUsername.DisplayMember = "UserId";
                        cmbUsername.ValueMember = "UserId";
                    }
                }
                else
                {
                    MessageBox.Show("System Not Registered");
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            sql = "select * from tbl_userinfo where UserId='" + cmbUsername.SelectedValue.ToString() + "' and Pwd='" + txtpwd.Text + "'";
            dt = dh.DataTable(sql);
            if (dt.Rows.Count > 0)
            {
                //DataHelper.FinYear = cmbfinancialyear.SelectedItem.ToString();
                DataHelper.UserId = cmbUsername.SelectedValue.ToString();
                MDI frmMdi = new MDI();
                frmMdi.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Username and Password doesn't match !!");
                txtpwd.Text = string.Empty;
                return;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtpwd_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin_Click(sender, e);
            }
        }
    }
}
