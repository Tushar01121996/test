﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace SchoolProject
{
    public partial class frmAdmitCard : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        string filename = string.Empty;
        string contentType = string.Empty;
        byte[] bytes;
        public frmAdmitCard()
        {
            InitializeComponent();
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);
            cmbClass.DataSource = dt;

            cmbClass.DisplayMember = "cname";
            cmbClass.ValueMember = "cid";
        }
        public void BindSection()
        {
            cmbSection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbClass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbSection.DataSource = dt;

            cmbSection.DisplayMember = "sname";
            cmbSection.ValueMember = "sid";
        }

        public void BindStudents()
        {
            cmbStudents.DataSource = null;

            sql = "select StuId,Name from Admission where Class='" + cmbClass.SelectedValue + "' and Section='" + cmbSection.SelectedValue + "' and IsActive=1";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Name--";
            dt.Rows.InsertAt(row, 0);
            cmbStudents.DataSource = dt;

            cmbStudents.DisplayMember = "Name";
            cmbStudents.ValueMember = "StuId";
        }
        public void BindStuData()
        {
            sql = "select * from Admission where Class='" + cmbClass.SelectedValue + "' and Section='" + cmbSection.SelectedValue + "' and StuId='" + cmbStudents.SelectedValue + "'";
            dt = dh.DataTable(sql);
            txtfname.Text = dt.Rows[0]["Fname"].ToString();
        }

        public void clearcontrols()
        {
            txtfname.Text = string.Empty;
            cmbStudents.SelectedIndex = 0;
            cmbSection.SelectedIndex = 0;
            cmbClass.SelectedIndex = 0;
        }

        private void frmStudentList_Load(object sender, EventArgs e)
        {
            try
            {
                BindClass();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    sql = "update Admission set ImageName='" + Path.GetFileName(filename) + "', ContentType='" + contentType + "' where Class='" + cmbClass.SelectedValue + "' and Section='" + cmbSection.SelectedValue + "' and StuId='" + cmbStudents.SelectedValue + "'";
            //    dh.ExecuteQuery(sql);
            //    MessageBox.Show("Image Upload Successfully !!");
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.ToString());
            //}
        }

        private void cmbClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbClass.SelectedIndex > 0)
            {
                BindSection();
            }
        }

        private void cmbSection_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbSection.SelectedIndex > 0)
                {
                    BindStudents();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void cmbStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbStudents.SelectedIndex > 0)
                {
                    BindStuData();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //clearcontrols();

            cry_AdmitCard cry = new cry_AdmitCard();
            frm_DisplayReport frm = new frm_DisplayReport();
            sql = "select a.*, c.cname as ClassName , s.sname as SectionName from admission  a inner join class_mas c on a.Class=c.cid inner join section_mas s on a.Section=s.sid where a.Class='" + cmbClass.SelectedValue + "' and a.Section='" + cmbSection.SelectedValue + "' and a.StuId='" + cmbStudents.SelectedValue + "'";

            dt = dh.DataTable(sql);
            if (dt.Rows.Count > 0)
            {
               
                cry.SetDataSource(dt);
                cry.SetParameterValue("Session", DataHelper.FinYear);
                cry.SetParameterValue("SchoolName", dh.getSchoolDetails().Rows[0]["SchoolName"].ToString());
                cry.SetParameterValue("Address", dh.getSchoolDetails().Rows[0]["Address"].ToString());
                frm.crystalReportViewer1.ReportSource = cry;
                frm.crystalReportViewer1.Refresh();
                frm.Show();
            }
            else
            {
                MessageBox.Show("Data Not found !!");
                return;
            }
        }

        private void lblUpload_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            uploadimage();
        }
        public void uploadimage()
        {
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog())
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    filename = openFileDialog1.FileName;
                    bytes = File.ReadAllBytes(filename);
                    contentType = "";
                    //Set the contenttype based on File Extension

                    switch (Path.GetExtension(filename))
                    {
                        case ".jpg":
                            contentType = "image/jpeg";
                            break;
                        case ".png":
                            contentType = "image/png";
                            break;
                        case ".gif":
                            contentType = "image/gif";
                            break;
                        case ".bmp":
                            contentType = "image/bmp";
                            break;
                    }



                }
            }
        }
    }
}
