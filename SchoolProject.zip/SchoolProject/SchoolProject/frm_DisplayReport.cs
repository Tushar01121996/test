﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frm_DisplayReport : Form
    {
        public frm_DisplayReport()
        {
            InitializeComponent();
        }
    }
}
