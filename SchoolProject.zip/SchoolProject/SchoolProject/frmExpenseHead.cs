﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmExpenseHead : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmExpenseHead()
        {
            InitializeComponent();
        }
        public void clearcontrols()
        {
            txtfesshead.Text = "";
            lblId.Text = "";
        }
        public string getMaxId()
        {
            sql = "select isnull(max(isnull(Convert(int,substring(ExpenseId,3,6)),0)),0) + 1 from ExpenseHead";
            dt = dh.DataTable(sql);
            string cid = dt.Rows[0][0].ToString();
            return cid;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            txtfesshead.Enabled = true;
            clearcontrols();
            txtfesshead.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtfesshead.Enabled = false;
            clearcontrols();
        }
        public void Bindgrid()
        {
            sql = "select ExpenseId,ExpenseName from ExpenseHead";
            dt = dh.DataTable(sql);
            dataGridView1.DataSource = dt;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                //lblId.Text = getMaxId();
                string sql = "select * from ExpenseHead where ExpenseId='" + lblId.Text + "'";
                dt = dh.DataTable(sql);

                if (dt.Rows.Count > 0)
                {
                    sql = "update ExpenseHead set ExpenseName='" + txtfesshead.Text + "' where ExpenseId='" + lblId.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Update !!");
                }
                else
                {
                    string cid = "EH" + getMaxId();
                    sql = "insert into ExpenseHead (ExpenseId,ExpenseName)values('" + cid + "','" + txtfesshead.Text.Trim() + "')";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("Data Saved !!");
                }
                txtfesshead.Enabled = false;
                Bindgrid();
                btnAdd.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                //sql = "select * from class_section_manage where cid='" + lblId.Text + "'";
                //dt = dh.DataTable(sql);
                //if (dt.Rows.Count > 0)
                //{
                //    MessageBox.Show("Class cannot delete because it is used in other process !!");
                //    return;
                //}
                //else
                //{
                //    sql = "delete from ExpenseHead where cid='" + lblId.Text + "'";
                //    dh.ExecuteQuery(sql);
                //    MessageBox.Show("Data Delete !!");
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void frmClassMaster_Load(object sender, EventArgs e)
        {
            txtfesshead.Enabled = false;
            btnAdd.Focus();
            Bindgrid();
            
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string cid = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                sql = "select * from ExpenseHead where ExpenseId='" + cid.ToString() + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    txtfesshead.Text = dt.Rows[0]["ExpenseName"].ToString();
                    lblId.Text = cid;
                }
                txtfesshead.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sql = "select ExpenseId,ExpenseName from ExpenseHead where ExpenseName like '%" + txtsearch.Text + "%'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtfesshead_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtfesshead_Enter(object sender, EventArgs e)
        {
            //btnsave.Focus();
        }

        private void txtfesshead_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                btnsave.Focus();
            }
        }

        private void btnAdd_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                txtfesshead.Focus();
            }
        }
    }
}
