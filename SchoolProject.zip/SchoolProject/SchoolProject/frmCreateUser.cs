﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmCreateUser : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmCreateUser()
        {
            InitializeComponent();
        }
       
        public void clearcontrols()
        {
            lblId.Text = "";
            txtpwd.Text = "";
            txtconfpwd.Text = "";
            cmbprofile.Text = "";
            txtuname.Text = "";
        }
        public void Bindgrid()
        {
            sql = "select Id, UserId from tbl_userinfo";
            dt = dh.DataTable(sql);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].Width = 220;
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtpwd.Text != txtconfpwd.Text)
                {
                    MessageBox.Show("Password doesn't match !!");
                    return;
                }

                string sql = "select * from tbl_userinfo where Id='" + lblId.Text + "'";
                dt = dh.DataTable(sql);

                if (dt.Rows.Count > 0)
                {
                    sql = "update tbl_userinfo set Pwd ='" + txtpwd.Text + "', Profile='" + cmbprofile.Text + "' where Id='" + lblId.Text + "'";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("User Update Successfully !!");
                }
                else
                {
                    sql = "insert into tbl_userinfo (Userid,Pwd,Profile)values('" + txtuname.Text + "','" + txtpwd.Text + "','" + cmbprofile.Text + "')";
                    dh.ExecuteQuery(sql);
                    MessageBox.Show("User Create Successfully!!");
                }
                txtuname.Enabled = false;
                txtpwd.Enabled = false;
                Bindgrid();
                btnAdd.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtuname.Enabled = false;
            txtpwd.Enabled = false;
            txtconfpwd.Enabled = false;
            cmbprofile.Enabled = false;
            clearcontrols();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtpwd.Enabled = true;
            txtuname.Enabled = true;
            txtconfpwd.Enabled = true;
            cmbprofile.Enabled = true;
            clearcontrols();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                //sql = "select * from class_section_manage where sid='" + lblId.Text + "'";
                //dt = dh.DataTable(sql);
                //if (dt.Rows.Count > 0)
                //{
                //    MessageBox.Show("Class cannot delete because it is used in other process !!");
                //    return;
                //}
                //else
                //{
                //    sql = "delete from class_section_manage where sid='" + lblId.Text + "'";
                //    dh.ExecuteQuery(sql);
                //    MessageBox.Show("Data Delete !!");
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sql = " select Id, UserId from tbl_userinfo  where UserId like '%" + txtsearch.Text + "%'";
                dt = dh.DataTable(sql);
                dataGridView1.DataSource = dt;
                dataGridView1.Columns[0].Width = 50;
                dataGridView1.Columns[1].Width = 220;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                sql = "select * from tbl_userinfo where Id='" + id.ToString() + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    lblId.Text = id;
                    string userid = dt.Rows[0]["UserId"].ToString();
                    string pwd = dt.Rows[0]["Pwd"].ToString();
                    string Profile = dt.Rows[0]["Profile"].ToString();
                    txtuname.Text = userid;
                    txtpwd.Text = pwd;
                    txtconfpwd.Text = pwd;
                    cmbprofile.Text = Profile;
                    //.Text = dt.Rows[0]["sname"].ToString();
                    //lblId.Text = sid;
                }
                txtpwd.Enabled = true;
                txtuname.Enabled = true;
                txtconfpwd.Enabled = true;
                cmbprofile.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void frmclasssectionManage_Load(object sender, EventArgs e)
        {
            lblId.Text = "";
          
            Bindgrid();
            txtpwd.Enabled = false;
            txtuname.Enabled = false;
            txtconfpwd.Enabled = false;
            cmbprofile.Enabled = false;
        }
    }
}
