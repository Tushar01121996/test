﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmCharacterCertificate : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmCharacterCertificate()
        {
            InitializeComponent();
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);
            cmbClass.DataSource = dt;

            cmbClass.DisplayMember = "cname";
            cmbClass.ValueMember = "cid";
        }
        public void BindSection()
        {
            cmbSection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbClass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbSection.DataSource = dt;

            cmbSection.DisplayMember = "sname";
            cmbSection.ValueMember = "sid";
        }
        private void frmStudentList_Load(object sender, EventArgs e)
        {
            try
            {
                BindClass();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            try
            {
                sql = "select * from CharacterCertificate where Class='" + cmbClass.SelectedValue + "' and Section='" + cmbSection.SelectedValue + "' and StuId='" + cmbStudents.SelectedValue + "' and Finyear='" + DataHelper.FinYear + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    sql = "update CharacterCertificate set years ='" + txtyears.Text + "' ,months='" + txtMonths.Text + "'  where Class='" + cmbClass.SelectedValue + "' and Section='" + cmbSection.SelectedValue + "' and StuId='" + cmbStudents.SelectedValue + "'";
                    sql += "and Finyear='" + DataHelper.FinYear + "'";
                    dh.ExecuteQuery(sql);
                   
                }
                else
                {
                    sql = "insert into CharacterCertificate(Class,Section,StuId,Finyear,years,months)values('" + cmbClass.SelectedValue + "','" + cmbSection.SelectedValue + "','" + cmbStudents.SelectedValue + "',";
                    sql += "'" + DataHelper.FinYear + "','" + txtyears.Text + "','" + txtMonths.Text + "')";
                    dh.ExecuteQuery(sql);
                }
                cry_CharacterCertificate cry = new cry_CharacterCertificate();
                frm_DisplayReport frm = new frm_DisplayReport();
                sql = "";
                sql += "                 select c.*, class_mas.cname as Class, section_mas.sname as Section, a.Name, a.Fname, a.Dob,a.PAdd from CharacterCertificate c inner join Admission a on a.Class=c.Class and a.Section=c.Section and a.StuId=c.StuId ";
                sql += " inner join Class_mas on c.Class=class_mas.cid";
                sql += " inner join Section_mas on c.Section=section_mas.sid";
                sql += " where c.Class='" + cmbClass.SelectedValue + "' and c.Section='" + cmbSection.SelectedValue + "' and c.StuId='" + cmbStudents.SelectedValue + "' and c.Finyear='" + DataHelper.FinYear + "'";
                // sql = "select * from CharacterCertificate where Class='" + cmbClass.SelectedValue + "' and Section='" + cmbSection.SelectedValue + "' and StuId='" + cmbStudents.SelectedValue + "' and Finyear='" + DataHelper.FinYear + "'";
                dt = dh.DataTable(sql);
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    cry.SetDataSource(dt);
                    cry.SetParameterValue("Session", DataHelper.FinYear);
                    cry.SetParameterValue("SchoolName", dh.getSchoolDetails().Rows[0]["SchoolName"].ToString());
                    cry.SetParameterValue("Address", dh.getSchoolDetails().Rows[0]["Address"].ToString());
                    frm.crystalReportViewer1.ReportSource = cry;
                    frm.crystalReportViewer1.Refresh();
                    frm.Show();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void cmbClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbClass.SelectedIndex > 0)
            {
                BindSection();
            }
        }
        public void BindStudents()
        {
            cmbStudents.DataSource = null;

            sql = "select StuId,Name from Admission where Class='" + cmbClass.SelectedValue + "' and Section='" + cmbSection.SelectedValue + "' and IsActive=1";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Name--";
            dt.Rows.InsertAt(row, 0);
            cmbStudents.DataSource = dt;

            cmbStudents.DisplayMember = "Name";
            cmbStudents.ValueMember = "StuId";
        }
        private void cmbStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cmbSection_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbSection.SelectedIndex > 0)
                {
                    BindStudents();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
