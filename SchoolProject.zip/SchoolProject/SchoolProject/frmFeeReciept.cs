﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmFeeReciept : Form
    {
        DataHelper dh = new DataHelper();
        DataTable dt = new DataTable();
        string sql = string.Empty;
        public frmFeeReciept()
        {
            InitializeComponent();
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);
            cmbclass.DataSource = dt;

            cmbclass.DisplayMember = "cname";
            cmbclass.ValueMember = "cid";
        }
        public void BindSection()
        {
            cmbsection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbclass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbsection.DataSource = dt;

            cmbsection.DisplayMember = "sname";
            cmbsection.ValueMember = "sid";
        }
        public void BindStudents()
        {
            cmbstudent.DataSource = null;

            sql = "select StuId,Name from Admission where IsActive ='1' and Class='" + cmbclass.SelectedValue + "' and Section ='" + cmbsection.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Student--";
            dt.Rows.InsertAt(row, 0);
            cmbstudent.DataSource = dt;

            cmbstudent.DisplayMember = "Name";
            cmbstudent.ValueMember = "StuId";
        }
        public void getStudentData()
        {
            if (cmbstudent.SelectedIndex > 0)
            {
                sql = "select * from Admission where StuId ='" + cmbstudent.SelectedValue + "'";
                dt = dh.DataTable(sql);
                lblfathername.Text = dt.Rows[0]["Fname"].ToString();

                sql = "select Top 1 * from Fee_RecMain where Class='" + cmbclass.SelectedValue + "' and Section='" + cmbsection.SelectedValue + "' and StuId='" + cmbstudent.SelectedValue + "'";
                sql += " order by Convert(int,substring(RecNo,5,10)) desc";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    lblprevbal.Text = dt.Rows[0]["DueAmount"].ToString();
                }
                else
                {
                    lblprevbal.Text = "0.00";
                }
                BindMonths();
                sql = "select * from Fee_recDtl where Class='" + cmbclass.SelectedValue + "' and Section='" + cmbsection.SelectedValue + "' and StuId='" + cmbstudent.SelectedValue + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        cmbmonths.Items.Remove(dt.Rows[i]["Month"].ToString());
                    }
                }
                //Calc();

            }
        }
        public void BindMonths()
        {
            cmbmonths.Items.Clear();
            for (int i = 1; i <= 12; i++)
            {
                cmbmonths.Items.Add(dh.GetMonthName(i));
            }
        }
        public void getMaxId()
        {
            sql = "select isnull(max(Convert(int,SUBSTRING(isnull(RecNo,0),5,9))),0) + 1 from Fee_RecMain where FinYear='" + DataHelper.FinYear + "'";
            dt = dh.DataTable(sql);
            string RecNo = "REC-" + dt.Rows[0][0].ToString();
            txtrecNo.Text = RecNo.ToString();
        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frmFeeReciept_Load(object sender, EventArgs e)
        {
            BindClass();
            clearcontrols();
            getMaxId();
            fillGrid();
        }

        private void cmbclass_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindSection();
        }
        public void clearcontrols()
        {
            getMaxId();
            cmbclass.SelectedIndex = 0;
            cmbsection.SelectedIndex = 0;
            cmbmonths.Text = "";
            txttotalamount.Text = "";
            txtremarks.Text = "";
            txtnetamt.Text = "";
            txtsearch.Text = "";
            //cmbstudent.SelectedIndex = 0;
            cmbmonths.Text = "";
            dgvdtl.Rows.Clear();
            txtremarks.Text = "";
            txtrecamount.Text = "";
            txtdueamt.Text = "";
            txtdiscount.Text = "";
            lblfathername.Text = "";
            lblprevbal.Text = "";
            txttotalamount.Text = "";
            txtnetamt.Text = "";
            dtpregdate.Value = DateTime.Now;

        }
        public void fillGrid()
        {
            sql = "select f.RecNo, a.Name, c.cname from Fee_RecMain f inner join Admission a on f.StuId=a.StuId inner join class_mas c on c.cid=f.Class";
            dt = dh.DataTable(sql);
            dgvmain.DataSource = dt;
        }

        private void cmbsection_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindStudents();
        }

        private void cmbstudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            getStudentData();

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                string query = string.Empty;
                DataTable dt1 = new DataTable();
                if (cmbclass.SelectedIndex > 0 && cmbsection.SelectedIndex > 0 && cmbmonths.Text != string.Empty && cmbstudent.SelectedIndex > 0)
                {
                    for (int i = 0; i < dgvdtl.Rows.Count - 1; i++)
                    {
                        if (cmbmonths.Text == dgvdtl.Rows[i].Cells[0].Value.ToString())
                        {
                            MessageBox.Show("Fees already Added for this month !!");
                            return;
                        }
                    }
                    sql = "select * from FeesMaster FM inner join FeesHead FH on FM.FeesHead=FH.HeadId where Class='" + cmbclass.SelectedValue + "' and Section ='" + cmbsection.SelectedValue + "'";
                    sql += " and Month='" + cmbmonths.Text + "'";
                    dt = dh.DataTable(sql);

                    query = "select BusFee,IsNew from Admission where StuId='" + cmbstudent.SelectedValue + "'";
                    dt1 = dh.DataTable(query);
                    if (dt1.Rows.Count > 0)
                    {
                        if (dt1.Rows[0][0].ToString() == "0")
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                DataRow dr = dt.Rows[i];
                                if (dr["HeadName"].ToString() == "BUS FEE")
                                    dr.Delete();
                            }

                            dt.AcceptChanges();
                        }
                        if (dt1.Rows[0][1].ToString() == "0")
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                DataRow dr = dt.Rows[i];
                                if (dr["HeadName"].ToString() == "ADMISSION FEE")
                                    dr.Delete();
                            }

                            dt.AcceptChanges();

                        }
                    }


                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string Month = dt.Rows[i]["Month"].ToString();
                            string FeeHead = dt.Rows[i]["HeadName"].ToString();
                            string Amount = dt.Rows[i]["Amount"].ToString();
                            dgvdtl.Rows.Add(Month, FeeHead, Amount);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please Select All Criteria (Class, Section, Student and Month) !!");
                    return;
                }
                Calc();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void Calc()
        {
            decimal TotAmount = 0;

            for (int i = 0; i < dgvdtl.Rows.Count - 1; i++)
            {
                string a = dgvdtl.Rows[i].Cells[2].Value.ToString();
                decimal amt = Convert.ToDecimal(a);
                TotAmount = TotAmount + amt;
            }
            txttotalamount.Text = TotAmount.ToString();

            decimal discount = string.IsNullOrEmpty(txtdiscount.Text) ? 0 : Convert.ToDecimal(txtdiscount.Text);
            decimal RecAmount = string.IsNullOrEmpty(txtrecamount.Text) ? 0 : Convert.ToDecimal(txtrecamount.Text);
            decimal preAmount = string.IsNullOrEmpty(lblprevbal.Text) ? 0 : Convert.ToDecimal(lblprevbal.Text);
            decimal totamt = TotAmount + preAmount;
            txtnetamt.Text = Convert.ToString(totamt - discount);
            txtdueamt.Text = Convert.ToString(Convert.ToDecimal(txtnetamt.Text) - RecAmount);

        }

        private void txtdiscount_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtrecamount_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbclass.SelectedIndex == 0)
                {
                    MessageBox.Show("Please Select Class !!");
                    return;
                }
                if (cmbsection.SelectedIndex == 0)
                {
                    MessageBox.Show("Please Select Section !!");
                    return;
                }
                if (cmbstudent.SelectedIndex == 0)
                {
                    MessageBox.Show("Please Select Student !!");
                    return;
                }
                if (string.IsNullOrEmpty(txtrecamount.Text) || txtrecamount.Text == "0")
                {
                    MessageBox.Show("Recieved amount cannnot be empty or zero !!");
                    return;
                }
                sql = "select * from Fee_RecMain where RecNo='" + txtrecNo.Text + "'";
                dt = dh.DataTable(sql);
                string payType = string.Empty;
                if (rdbcash.Checked == true)
                {
                    payType = rdbcash.Text;
                }
                else if (rdbCheque.Checked == true)
                {
                    payType = rdbCheque.Text;
                }
                else if (rdbCard.Checked == true)
                {
                    payType = rdbCard.Text;
                }
                string lastdues = lblprevbal.Text;
                if (dt.Rows.Count == 0)
                {
                    string discount = string.IsNullOrEmpty(txtdiscount.Text) ? "0" : txtdiscount.Text;
                    sql = "insert into Fee_RecMain (RecNo,StuId,Class,Section,RecDate,TotalAmount,NetAmount,Remarks,DueAmount,RecAmount,Discount,LateFine,FinYear,UserId,CrDate,PayType,LastDues)values(";
                    sql += "'" + txtrecNo.Text + "'";
                    sql += ",'" + cmbstudent.SelectedValue + "'";
                    sql += ",'" + cmbclass.SelectedValue + "'";
                    sql += ",'" + cmbsection.SelectedValue + "'";
                    sql += ",'" + dtpregdate.Value.ToString("yyyy-MM-dd") + "'";
                    sql += ",'" + txttotalamount.Text + "'";
                    sql += ",'" + txtnetamt.Text + "'";
                    sql += ",'" + txtremarks.Text + "'";
                    sql += ",'" + txtdueamt.Text + "'";
                    sql += ",'" + txtrecamount.Text + "'";
                    sql += ",'" + discount + "'";
                    sql += ",'" + '0' + "'";
                    sql += ",'" + DataHelper.FinYear + "'";
                    sql += ",'" + DataHelper.UserId + "'";
                    sql += ",'" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + payType + "','" + lastdues + "')";
                    dh.ExecuteQuery(sql);

                    for (int i = 0; i < dgvdtl.Rows.Count - 1; i++)
                    {
                        string month = dgvdtl.Rows[i].Cells[0].Value.ToString();
                        string FeesHead = dgvdtl.Rows[i].Cells[1].Value.ToString();
                        string Amount = dgvdtl.Rows[i].Cells[2].Value.ToString();

                        sql = "insert into Fee_RecDtl(RecNo,Class,Section,StuId,Month,FeesHead,Amount)values(";
                        sql += "'" + txtrecNo.Text + "'";
                        sql += ",'" + cmbclass.SelectedValue + "'";
                        sql += ",'" + cmbsection.SelectedValue + "'";
                        sql += ",'" + cmbstudent.SelectedValue + "'";
                        sql += ",'" + month + "'";
                        sql += ",'" + FeesHead + "'";
                        sql += ",'" + Amount + "')";
                        dh.ExecuteQuery(sql);
                    }
                }
                MessageBox.Show("Fees Generate Successfully !!");
                fillGrid();
                pnlfirst.Enabled = false;
                pnl3.Enabled = false;
                dgvdtl.Enabled = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            clearcontrols();
            getMaxId();
            BindMonths();
            pnlfirst.Enabled = true;
            pnl3.Enabled = true;
            dgvdtl.Enabled = true;
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            try
            {
                sql = "select * from Fee_RecMain where RecNo='" + txtrecNo.Text + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    sql = "delete from Fee_RecMain where RecNo='" + txtrecNo.Text + "'";
                    dh.ExecuteQuery(sql);

                    sql = "delete from Fee_RecDtl where RecNo='" + txtrecNo.Text + "'";
                    dh.ExecuteQuery(sql);

                    MessageBox.Show("Reciept Deleted Successfully !!");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            clearcontrols();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                cry_FeeReceipt cry = new cry_FeeReceipt();
                frm_DisplayReport frm = new frm_DisplayReport();
                sql = "";
                sql += "                select fm.RecNo, fm.TotalAmount, fm.NetAmount, fm.Discount, fm.LateFine, fm.DueAmount, fm.RecDate, fm.FinYear, fm.Remarks," + Environment.NewLine;
                sql += "fd.Amount,fm.RecAmount, fd.Month, fd.FeesHead, cm.cname as Class, sm.sname as section, a.Name, a.Fname, fm.LastDues from Fee_RecMain fm inner join   Fee_RecDtl fd on fm.RecNo=fd.RecNo" + Environment.NewLine;
                sql += "inner join class_mas cm on cm.cid=fm.Class" + Environment.NewLine;
                sql += "inner join section_mas sm on sm.sid=fm.Section" + Environment.NewLine;
                sql += "inner join Admission a on a.StuId=fm.StuId" + Environment.NewLine;
                sql += " where fm.RecNo='" + txtrecNo.Text + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    cry.SetDataSource(dt);
                    cry.SetParameterValue("SchoolName", dh.getSchoolDetails().Rows[0]["SchoolName"].ToString());
                    cry.SetParameterValue("Address", dh.getSchoolDetails().Rows[0]["Address"].ToString());
                    frm.crystalReportViewer1.ReportSource = cry;
                    frm.crystalReportViewer1.Refresh();
                    frm.Show();
                }
                else
                {
                    MessageBox.Show("Data Not found !!");
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dgvmain_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                dgvdtl.Rows.Clear();
                string RecNo = dgvmain.CurrentRow.Cells[0].Value.ToString();
                txtrecNo.Text = RecNo;
                string sqlq = string.Empty;
                DataTable dtq = new DataTable();
                sqlq = "select * from fee_recmain where RecNo='" + RecNo + "'";
                dtq = dh.DataTable(sqlq);
                if (dtq.Rows.Count > 0)
                {
                    string Class = dtq.Rows[0]["Class"].ToString();
                    string Section = dtq.Rows[0]["Section"].ToString();
                    string Student = dtq.Rows[0]["StuId"].ToString();
                    decimal totamt = Convert.ToDecimal(dtq.Rows[0]["TotalAmount"].ToString());
                    decimal netamt = Convert.ToDecimal(dtq.Rows[0]["NetAmount"].ToString());
                    decimal discount = Convert.ToDecimal(dtq.Rows[0]["Discount"].ToString());
                    string remarks = dtq.Rows[0]["Remarks"].ToString();
                    decimal dueamt = Convert.ToDecimal(dtq.Rows[0]["DueAmount"].ToString());
                    decimal recamt = Convert.ToDecimal(dtq.Rows[0]["RecAmount"].ToString());
                    string recdate = dtq.Rows[0]["RecDate"].ToString();
                    string latefine = dtq.Rows[0]["LateFine"].ToString();
                    string paytype = dtq.Rows[0]["PayType"].ToString();

                    txttotalamount.Text = totamt.ToString();
                    txtnetamt.Text = netamt.ToString();
                    txtdueamt.Text = dueamt.ToString();
                    txtrecamount.Text = recamt.ToString();
                    txtdiscount.Text = discount.ToString();
                    txtremarks.Text = remarks;
                    dtpregdate.Value = Convert.ToDateTime(recdate);
                    cmbclass.SelectedValue = Class;
                    cmbsection.SelectedValue = Section;
                    cmbstudent.SelectedValue = Student;
                    if (paytype == "Cash")
                    {
                        rdbcash.Checked = true;
                    }
                    else if (paytype == "Cheque")
                    {
                        rdbCheque.Checked = true;
                    }
                    else if (paytype == "Card")
                    {
                        rdbCard.Checked = true;
                    }
                }
                sql = "select * from fee_recdtl where RecNo='" + RecNo + "'";
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string FeesHead = dt.Rows[i]["FeesHead"].ToString();
                        string Month = dt.Rows[i]["Month"].ToString();
                        string Amount = dt.Rows[i]["Amount"].ToString();
                        dgvdtl.Rows.Add(FeesHead, Month, Amount);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtrecamount_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                Calc();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtdiscount_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                Calc();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void cmbstudent_KeyUp(object sender, KeyEventArgs e)
        {
            getStudentData();
        }
    }
}
