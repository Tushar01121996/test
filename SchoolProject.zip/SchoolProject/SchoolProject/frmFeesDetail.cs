﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolProject
{
    public partial class frmFeesDetail : Form
    {
        DataHelper dh = new DataHelper();
        string sql = string.Empty;
        DataTable dt = new DataTable();
        public frmFeesDetail()
        {
            InitializeComponent();
        }
        public void BindClass()
        {
            sql = "select cid,cname from class_mas";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Class--";
            dt.Rows.InsertAt(row, 0);
            cmbclass.DataSource = dt;

            cmbclass.DisplayMember = "cname";
            cmbclass.ValueMember = "cid";
        }
        public void BindSection()
        {
            cmbsection.DataSource = null;

            sql = "select sm.sid,sm.sname from class_section_manage cm inner join Section_mas sm on cm.sid=sm.sid where cm.cid='" + cmbclass.SelectedValue + "'";
            dt = dh.DataTable(sql);
            DataRow row = dt.NewRow();
            row[0] = "0";
            row[1] = "--Section--";
            dt.Rows.InsertAt(row, 0);
            cmbsection.DataSource = dt;

            cmbsection.DisplayMember = "sname";
            cmbsection.ValueMember = "sid";
        }
        private void btnShow_Click(object sender, EventArgs e)
        {
            try
            {
                sql = "";
                sql += "                 select a.Name, a.Fname,cm.cname as Class, sm.sname as Section, f.RecNo,f.RecDate, f.TotalAmount,f.NetAmount, f.DueAmount, f.RecAmount, f.LateFine, f.Discount" + Environment.NewLine;
                sql += "  from fee_recmain f" + Environment.NewLine;
                sql += " inner join Admission a on a.StuId=f.StuId" + Environment.NewLine;
                sql += " inner join class_mas cm on cm.cid=f.Class" + Environment.NewLine;
                sql += " inner join section_mas sm on sm.sid=f.Section" + Environment.NewLine;
                sql += " where f.RecDate between Convert(date,'" + dtp1.Value.ToString("yyyy-MM-dd") + "') and Convert(date,'" + dtp2.Value.ToString("yyyy-MM-dd") + "')";
                if (cmbclass.SelectedIndex > 0)
                {
                    sql += " and f.class='" + cmbclass.SelectedValue + "'";
                }
                if (cmbsection.SelectedIndex > 0)
                {
                    sql += " and f.Section='" + cmbsection.SelectedValue + "'";
                }
                dt = dh.DataTable(sql);
                if (dt.Rows.Count > 0)
                {
                    decimal totamount = 0;
                    decimal recamount = 0;
                    decimal dueamt = 0;
                    decimal discount = 0;
                    decimal latefine = 0;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        totamount = totamount + Convert.ToDecimal(dt.Rows[i]["TotalAmount"].ToString());
                        recamount = recamount + Convert.ToDecimal(dt.Rows[i]["RecAmount"].ToString());
                        discount = discount + Convert.ToDecimal(dt.Rows[i]["Discount"].ToString());
                        latefine = latefine + Convert.ToDecimal(dt.Rows[i]["LateFine"].ToString());
                    }
                    dueamt = totamount - recamount;
                    txttotalamount.Text = totamount.ToString();
                    txtrecamount.Text = recamount.ToString();
                    txtdueamt.Text = dueamt.ToString();
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No Record Found !!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    cry_FeeDetail cry = new cry_FeeDetail();
                    frm_DisplayReport frm = new frm_DisplayReport();
                    sql = "";
                    sql += "                 select a.Name, a.Fname,cm.cname as Class, sm.sname as Section, f.RecNo,f.RecDate, f.TotalAmount,f.NetAmount, f.DueAmount, f.RecAmount, f.LateFine, f.Discount" + Environment.NewLine;
                    sql += "  from fee_recmain f" + Environment.NewLine;
                    sql += " inner join Admission a on a.StuId=f.StuId" + Environment.NewLine;
                    sql += " inner join class_mas cm on cm.cid=f.Class" + Environment.NewLine;
                    sql += " inner join section_mas sm on sm.sid=f.Section" + Environment.NewLine;
                    sql += " where f.RecDate between Convert(date,'" + dtp1.Value.ToString("yyyy-MM-dd") + "') and Convert(date,'" + dtp2.Value.ToString("yyyy-MM-dd") + "')";
                    if (cmbclass.SelectedIndex > 0)
                    {
                        sql += " and f.class='" + cmbclass.SelectedValue + "'";
                    }
                    if (cmbsection.SelectedIndex > 0)
                    {
                        sql += " and f.Section='" + cmbsection.SelectedValue + "'";
                    }
                    dt = dh.DataTable(sql);
                    if (dt.Rows.Count > 0)
                    {
                        cry.SetDataSource(dt);
                        cry.SetParameterValue("FromDate", dtp1.Value.ToString("dd-MMM-yyyy"));
                        cry.SetParameterValue("ToDate", dtp2.Value.ToString("dd-MMM-yyyy"));
                        cry.SetParameterValue("Session", DataHelper.FinYear);
                        cry.SetParameterValue("SchoolName", dh.getSchoolDetails().Rows[0]["SchoolName"].ToString());
                        cry.SetParameterValue("Address", dh.getSchoolDetails().Rows[0]["Address"].ToString());
                        frm.crystalReportViewer1.ReportSource = cry;
                        frm.crystalReportViewer1.Refresh();
                        frm.Show();
                    }
                    else
                    {
                        MessageBox.Show("No Record Found !!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void cmbclass_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindSection();
        }

        private void frmFeesDetail_Load(object sender, EventArgs e)
        {
            BindClass();
        }
    }
}
